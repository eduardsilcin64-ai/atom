import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import CityCard from "@/components/CityCard";
import { Plus, Search, MapPin } from "lucide-react";
import { useState } from "react";

const mockCities = [
  { id: "balakovo", name: "Балаково", organizerName: "Иванов И.И.", eventsCount: 12, pendingEvents: 2, budget: { total: 1200000, approved: 720000, spent: 450000 } },
  { id: "obninsk", name: "Обнинск", organizerName: "Петров П.П.", eventsCount: 8, pendingEvents: 0, budget: { total: 800000, approved: 780000, spent: 720000 }, hasWarnings: true },
  { id: "kurchatov", name: "Курчатов", organizerName: "Сидоров С.С.", eventsCount: 6, pendingEvents: 1, budget: { total: 600000, approved: 350000, spent: 200000 } },
  { id: "sosnovybor", name: "Сосновый Бор", organizerName: "Козлова А.В.", eventsCount: 10, pendingEvents: 0, budget: { total: 900000, approved: 500000, spent: 480000 } },
  { id: "novovoronezh", name: "Нововоронеж", organizerName: "Морозов Д.К.", eventsCount: 5, pendingEvents: 3, budget: { total: 500000, approved: 200000, spent: 150000 } },
  { id: "zarechny", name: "Заречный", organizerName: "Новикова Е.А.", eventsCount: 7, pendingEvents: 0, budget: { total: 700000, approved: 400000, spent: 350000 } },
  { id: "desnogorsk", name: "Десногорск", organizerName: "Смирнов К.Л.", eventsCount: 4, pendingEvents: 1, budget: { total: 450000, approved: 250000, spent: 180000 } },
  { id: "polyarnye-zori", name: "Полярные Зори", organizerName: "Волков Р.Н.", eventsCount: 3, pendingEvents: 0, budget: { total: 350000, approved: 200000, spent: 150000 } },
];

interface CitiesPageProps {
  onNavigateCity?: (cityId: string) => void;
}

export default function CitiesPage({ onNavigateCity }: CitiesPageProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCities = mockCities.filter(city =>
    city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    city.organizerName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalBudget = mockCities.reduce((sum, c) => sum + c.budget.total, 0);
  const totalEvents = mockCities.reduce((sum, c) => sum + c.eventsCount, 0);

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 }).format(amount);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Города</h1>
          <p className="text-muted-foreground">Управление городами-участниками проекта</p>
        </div>
        <Button data-testid="button-add-city">
          <Plus className="h-4 w-4 mr-2" />
          Добавить город
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <MapPin className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{mockCities.length}</p>
              <p className="text-sm text-muted-foreground">Городов в проекте</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-2/10 text-chart-2">
              <MapPin className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{totalEvents}</p>
              <p className="text-sm text-muted-foreground">Мероприятий всего</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-4/10 text-chart-4">
              <MapPin className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono">{formatCurrency(totalBudget)}</p>
              <p className="text-sm text-muted-foreground">Общий бюджет</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск городов..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-cities"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCities.map((city) => (
          <CityCard
            key={city.id}
            {...city}
            onClick={() => onNavigateCity?.(city.id)}
          />
        ))}
      </div>

      {filteredCities.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">Города не найдены</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
