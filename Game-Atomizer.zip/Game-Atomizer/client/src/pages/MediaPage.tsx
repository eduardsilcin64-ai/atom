import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Search, Image, Video, FileText, Calendar, Eye, Download, Trash2, Plus } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

type MediaType = "image" | "video" | "document";

interface MediaItem {
  id: string;
  name: string;
  type: MediaType;
  eventTitle: string;
  uploadedAt: Date;
  size: string;
  views?: number;
}

const mockMedia: MediaItem[] = [
  { id: "1", name: "cs2_tournament_poster.jpg", type: "image", eventTitle: "Кубок CS2", uploadedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), size: "2.4 MB", views: 1250 },
  { id: "2", name: "fifa_highlights.mp4", type: "video", eventTitle: "Турнир FIFA", uploadedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), size: "156 MB", views: 8500 },
  { id: "3", name: "dota2_report.pdf", type: "document", eventTitle: "Чемпионат Dota 2", uploadedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), size: "1.2 MB" },
  { id: "4", name: "valorant_announcement.jpg", type: "image", eventTitle: "Лига Valorant", uploadedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), size: "1.8 MB", views: 2100 },
  { id: "5", name: "event_photos_batch.zip", type: "document", eventTitle: "Турнир FIFA", uploadedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), size: "45.6 MB" },
  { id: "6", name: "winner_interview.mp4", type: "video", eventTitle: "Чемпионат Dota 2", uploadedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), size: "89 MB", views: 12400 },
];

const typeIcons: Record<MediaType, typeof Image> = {
  image: Image,
  video: Video,
  document: FileText,
};

const typeLabels: Record<MediaType, string> = {
  image: "Изображение",
  video: "Видео",
  document: "Документ",
};

export default function MediaPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [activeTab, setActiveTab] = useState("all");

  const filteredMedia = mockMedia.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.eventTitle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === "all" || item.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const imageCount = mockMedia.filter(m => m.type === "image").length;
  const videoCount = mockMedia.filter(m => m.type === "video").length;
  const docCount = mockMedia.filter(m => m.type === "document").length;
  const totalViews = mockMedia.reduce((sum, m) => sum + (m.views || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Медиа</h1>
          <p className="text-muted-foreground">Управление медиафайлами событий</p>
        </div>
        <Button data-testid="button-upload-media">
          <Upload className="h-4 w-4 mr-2" />
          Загрузить файл
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <Image className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{imageCount}</p>
              <p className="text-sm text-muted-foreground">Изображений</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-2/10 text-chart-2">
              <Video className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{videoCount}</p>
              <p className="text-sm text-muted-foreground">Видео</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-3/10 text-chart-3">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{docCount}</p>
              <p className="text-sm text-muted-foreground">Документов</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-4/10 text-chart-4">
              <Eye className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono">{(totalViews / 1000).toFixed(1)}K</p>
              <p className="text-sm text-muted-foreground">Просмотров</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск файлов..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-media"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[180px]" data-testid="select-type-filter">
            <SelectValue placeholder="Тип файла" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все типы</SelectItem>
            <SelectItem value="image">Изображения</SelectItem>
            <SelectItem value="video">Видео</SelectItem>
            <SelectItem value="document">Документы</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {filteredMedia.map((item) => {
              const Icon = typeIcons[item.type];
              return (
                <div 
                  key={item.id}
                  className="flex items-center justify-between gap-4 p-4 hover-elevate"
                  data-testid={`media-item-${item.id}`}
                >
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-md bg-muted">
                      <Icon className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{item.name}</span>
                        <Badge variant="outline">{typeLabels[item.type]}</Badge>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground flex-wrap">
                        <span>{item.eventTitle}</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {format(item.uploadedAt, "d MMM yyyy", { locale: ru })}
                        </span>
                        <span>{item.size}</span>
                        {item.views && (
                          <span className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {item.views.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" data-testid={`button-download-${item.id}`}>
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" data-testid={`button-delete-${item.id}`}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {filteredMedia.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">Файлы не найдены</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
