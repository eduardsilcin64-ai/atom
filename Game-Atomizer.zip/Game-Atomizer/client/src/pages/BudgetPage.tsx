import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import BudgetProgress from "@/components/BudgetProgress";
import { Wallet, TrendingUp, Calendar, FileText, Download } from "lucide-react";

const mockBudgetData = {
  total: 1200000,
  approved: 720000,
  spent: 450000,
  pending: 180000,
};

const mockExpenses = [
  { id: "1", title: "Призовой фонд CS2", amount: 150000, category: "Призы", date: new Date(2024, 10, 15), status: "paid" },
  { id: "2", title: "Аренда площадки FIFA", amount: 45000, category: "Аренда", date: new Date(2024, 10, 20), status: "paid" },
  { id: "3", title: "Оборудование Dota 2", amount: 80000, category: "Техника", date: new Date(2024, 11, 1), status: "pending" },
  { id: "4", title: "Маркетинг события", amount: 35000, category: "Маркетинг", date: new Date(2024, 11, 5), status: "paid" },
  { id: "5", title: "Призовой фонд Valorant", amount: 120000, category: "Призы", date: new Date(2024, 11, 10), status: "pending" },
];

const mockQuarterlyBudget = [
  { quarter: "Q1", allocated: 300000, spent: 280000 },
  { quarter: "Q2", allocated: 300000, spent: 310000 },
  { quarter: "Q3", allocated: 300000, spent: 275000 },
  { quarter: "Q4", allocated: 300000, spent: 150000 },
];

export default function BudgetPage() {
  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 }).format(amount);

  const formatDate = (date: Date) =>
    new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short" }).format(date);

  const remaining = mockBudgetData.approved - mockBudgetData.spent;
  const spentPercentage = (mockBudgetData.spent / mockBudgetData.approved) * 100;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Бюджет</h1>
          <p className="text-muted-foreground">Управление бюджетом города Балаково</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-export-budget">
            <Download className="h-4 w-4 mr-2" />
            Экспорт
          </Button>
          <Button data-testid="button-request-budget">
            <FileText className="h-4 w-4 mr-2" />
            Запросить бюджет
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono">{formatCurrency(mockBudgetData.total)}</p>
              <p className="text-sm text-muted-foreground">Годовой бюджет</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-2/10 text-chart-2">
              <TrendingUp className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono">{formatCurrency(mockBudgetData.approved)}</p>
              <p className="text-sm text-muted-foreground">Утверждено</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-4/10 text-chart-4">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono">{formatCurrency(mockBudgetData.spent)}</p>
              <p className="text-sm text-muted-foreground">Израсходовано</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-3/10 text-chart-3">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono">{formatCurrency(remaining)}</p>
              <p className="text-sm text-muted-foreground">Остаток</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Освоение бюджета</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <BudgetProgress
              total={mockBudgetData.total}
              approved={mockBudgetData.approved}
              spent={mockBudgetData.spent}
            />
            <div className="pt-4 space-y-3">
              {mockQuarterlyBudget.map((q) => (
                <div key={q.quarter} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span>{q.quarter} 2024</span>
                    <span className="font-mono">
                      {formatCurrency(q.spent)} / {formatCurrency(q.allocated)}
                    </span>
                  </div>
                  <Progress 
                    value={(q.spent / q.allocated) * 100} 
                    className="h-2"
                  />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4">
            <CardTitle>Последние расходы</CardTitle>
            <Button variant="ghost" size="sm" data-testid="button-view-all-expenses">
              Все расходы
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {mockExpenses.map((expense) => (
                <div 
                  key={expense.id}
                  className="flex items-center justify-between gap-4 p-3 rounded-md bg-muted"
                  data-testid={`expense-item-${expense.id}`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium">{expense.title}</span>
                      <Badge variant="outline">{expense.category}</Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {formatDate(expense.date)}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold font-mono">{formatCurrency(expense.amount)}</p>
                    <Badge variant={expense.status === "paid" ? "secondary" : "outline"}>
                      {expense.status === "paid" ? "Оплачено" : "Ожидает"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
