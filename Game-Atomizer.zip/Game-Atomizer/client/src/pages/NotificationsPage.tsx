import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Calendar, Wallet, CheckCircle2, AlertCircle, Info, Check, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

type NotificationType = "approval" | "budget" | "event" | "system";

interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: Date;
  isRead: boolean;
}

const mockNotifications: Notification[] = [
  { id: "1", type: "approval", title: "Календарь утверждён", message: "Событие 'Кубок CS2' добавлено в календарь", createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000), isRead: false },
  { id: "2", type: "budget", title: "Бюджет одобрен", message: "Бюджет на событие 'Турнир FIFA' утверждён на сумму 150 000 ₽", createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000), isRead: false },
  { id: "3", type: "event", title: "Напоминание о событии", message: "Событие 'Лига Valorant' начнётся через 7 дней", createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000), isRead: true },
  { id: "4", type: "system", title: "Обновление системы", message: "Добавлена новая функция отчётности", createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), isRead: true },
  { id: "5", type: "budget", title: "Требуется отчёт", message: "Пожалуйста, загрузите финансовый отчёт за октябрь", createdAt: new Date(Date.now() - 48 * 60 * 60 * 1000), isRead: true },
  { id: "6", type: "approval", title: "Ожидает утверждения", message: "Календарь события 'Чемпионат Dota 2' ожидает утверждения", createdAt: new Date(Date.now() - 72 * 60 * 60 * 1000), isRead: true },
];

const typeIcons: Record<NotificationType, typeof Bell> = {
  approval: CheckCircle2,
  budget: Wallet,
  event: Calendar,
  system: Info,
};

const typeColors: Record<NotificationType, string> = {
  approval: "text-chart-2",
  budget: "text-chart-4",
  event: "text-primary",
  system: "text-muted-foreground",
};

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState(mockNotifications);
  const [activeTab, setActiveTab] = useState("all");

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const filteredNotifications = notifications.filter(n => {
    if (activeTab === "all") return true;
    if (activeTab === "unread") return !n.isRead;
    return n.type === activeTab;
  });

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    
    if (hours < 1) return "Только что";
    if (hours < 24) return `${hours}ч назад`;
    if (days < 7) return `${days}д назад`;
    return format(date, "d MMM", { locale: ru });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Уведомления</h1>
          <p className="text-muted-foreground">
            {unreadCount > 0 ? `${unreadCount} непрочитанных` : "Все прочитаны"}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" onClick={markAllAsRead} data-testid="button-mark-all-read">
            <Check className="h-4 w-4 mr-2" />
            Прочитать все
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <Bell className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{notifications.length}</p>
              <p className="text-sm text-muted-foreground">Всего</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-destructive/10 text-destructive">
              <AlertCircle className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{unreadCount}</p>
              <p className="text-sm text-muted-foreground">Непрочитанных</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-2/10 text-chart-2">
              <CheckCircle2 className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{notifications.filter(n => n.type === "approval").length}</p>
              <p className="text-sm text-muted-foreground">Утверждения</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-4/10 text-chart-4">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{notifications.filter(n => n.type === "budget").length}</p>
              <p className="text-sm text-muted-foreground">Бюджет</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all" data-testid="tab-all">Все</TabsTrigger>
          <TabsTrigger value="unread" data-testid="tab-unread">
            Непрочитанные
            {unreadCount > 0 && (
              <span className="ml-1.5 px-1.5 py-0.5 text-xs rounded-full bg-destructive text-destructive-foreground">
                {unreadCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="approval" data-testid="tab-approval">Утверждения</TabsTrigger>
          <TabsTrigger value="budget" data-testid="tab-budget">Бюджет</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          <Card>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {filteredNotifications.map((notification) => {
                  const Icon = typeIcons[notification.type];
                  return (
                    <div 
                      key={notification.id}
                      className={`flex items-start gap-4 p-4 ${!notification.isRead ? 'bg-muted/50' : ''}`}
                      data-testid={`notification-${notification.id}`}
                    >
                      <div className={`p-2 rounded-md bg-muted ${typeColors[notification.type]}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{notification.title}</span>
                          {!notification.isRead && (
                            <Badge variant="default" className="text-xs">Новое</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{notification.message}</p>
                        <p className="text-xs text-muted-foreground">{formatTime(notification.createdAt)}</p>
                      </div>
                      <div className="flex gap-1">
                        {!notification.isRead && (
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => markAsRead(notification.id)}
                            data-testid={`button-mark-read-${notification.id}`}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                        )}
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => deleteNotification(notification.id)}
                          data-testid={`button-delete-${notification.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {filteredNotifications.length === 0 && (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Нет уведомлений</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
