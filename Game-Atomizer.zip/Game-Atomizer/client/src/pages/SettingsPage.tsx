import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Settings, User, Bell, Shield, Palette, Save } from "lucide-react";

interface SettingsPageProps {
  userName?: string;
  userEmail?: string;
  userRole?: "super_admin" | "city_org" | "smm";
}

export default function SettingsPage({ 
  userName = "Пользователь", 
  userEmail = "user@atom.game",
  userRole = "city_org"
}: SettingsPageProps) {
  const roleLabels = {
    super_admin: "Администратор",
    city_org: "Организатор города",
    smm: "SMM-специалист",
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold">Настройки</h1>
        <p className="text-muted-foreground">Управление настройками аккаунта</p>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <User className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle>Профиль</CardTitle>
                <CardDescription>Основная информация о пользователе</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center gap-6">
              <Avatar className="h-20 w-20">
                <AvatarFallback className="text-2xl">
                  {userName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="space-y-2">
                <Button variant="outline" data-testid="button-change-avatar">
                  Сменить аватар
                </Button>
                <p className="text-sm text-muted-foreground">JPG, PNG до 2MB</p>
              </div>
            </div>

            <Separator />

            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Имя</Label>
                <Input 
                  id="name" 
                  defaultValue={userName}
                  data-testid="input-name"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  defaultValue={userEmail}
                  data-testid="input-email"
                />
              </div>
              <div className="grid gap-2">
                <Label>Роль</Label>
                <Input 
                  value={roleLabels[userRole]} 
                  disabled 
                  className="bg-muted"
                />
              </div>
            </div>

            <Button data-testid="button-save-profile">
              <Save className="h-4 w-4 mr-2" />
              Сохранить изменения
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Bell className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle>Уведомления</CardTitle>
                <CardDescription>Настройка уведомлений и оповещений</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Email уведомления</Label>
                <p className="text-sm text-muted-foreground">Получать уведомления на почту</p>
              </div>
              <Switch defaultChecked data-testid="switch-email-notifications" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Уведомления об утверждениях</Label>
                <p className="text-sm text-muted-foreground">Уведомлять о статусе заявок</p>
              </div>
              <Switch defaultChecked data-testid="switch-approval-notifications" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Напоминания о событиях</Label>
                <p className="text-sm text-muted-foreground">Напоминать о предстоящих событиях</p>
              </div>
              <Switch defaultChecked data-testid="switch-event-reminders" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Уведомления о бюджете</Label>
                <p className="text-sm text-muted-foreground">Уведомлять об изменениях бюджета</p>
              </div>
              <Switch defaultChecked data-testid="switch-budget-notifications" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle>Безопасность</CardTitle>
                <CardDescription>Настройки безопасности аккаунта</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="current-password">Текущий пароль</Label>
                <Input 
                  id="current-password" 
                  type="password"
                  data-testid="input-current-password"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="new-password">Новый пароль</Label>
                <Input 
                  id="new-password" 
                  type="password"
                  data-testid="input-new-password"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="confirm-password">Подтвердите пароль</Label>
                <Input 
                  id="confirm-password" 
                  type="password"
                  data-testid="input-confirm-password"
                />
              </div>
            </div>
            <Button variant="outline" data-testid="button-change-password">
              Сменить пароль
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Palette className="h-5 w-5 text-muted-foreground" />
              <div>
                <CardTitle>Внешний вид</CardTitle>
                <CardDescription>Настройка внешнего вида приложения</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Компактный режим</Label>
                <p className="text-sm text-muted-foreground">Уменьшить отступы и размеры элементов</p>
              </div>
              <Switch data-testid="switch-compact-mode" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Анимации</Label>
                <p className="text-sm text-muted-foreground">Включить анимации интерфейса</p>
              </div>
              <Switch defaultChecked data-testid="switch-animations" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
