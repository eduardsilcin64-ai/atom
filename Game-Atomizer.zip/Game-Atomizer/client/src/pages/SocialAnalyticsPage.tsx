import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { SiVk, SiTelegram, SiYoutube } from "react-icons/si";
import { TrendingUp, TrendingDown, Users, Eye, Heart, MessageCircle, Share2, BarChart3, Calendar } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, PieChart, Pie, Cell } from "recharts";

const monthlyData = [
  { month: "Янв", vk: 45200, tg: 12300, youtube: 8500 },
  { month: "Фев", vk: 52100, tg: 15600, youtube: 9200 },
  { month: "Мар", vk: 48900, tg: 18200, youtube: 11000 },
  { month: "Апр", vk: 61500, tg: 22100, youtube: 13500 },
  { month: "Май", vk: 58700, tg: 25800, youtube: 15200 },
  { month: "Июн", vk: 67200, tg: 28900, youtube: 17800 },
  { month: "Июл", vk: 72100, tg: 32500, youtube: 19500 },
  { month: "Авг", vk: 69800, tg: 35200, youtube: 21200 },
  { month: "Сен", vk: 78500, tg: 38700, youtube: 23800 },
  { month: "Окт", vk: 82300, tg: 42100, youtube: 26500 },
  { month: "Ноя", vk: 89700, tg: 45800, youtube: 29200 },
  { month: "Дек", vk: 95200, tg: 48900, youtube: 31500 },
];

const cityStats = [
  { city: "Балаково", vk: 125400, tg: 45200, youtube: 32100, engagement: 8.5 },
  { city: "Обнинск", vk: 98700, tg: 38500, youtube: 28700, engagement: 7.2 },
  { city: "Сосновый Бор", vk: 87600, tg: 32100, youtube: 24500, engagement: 9.1 },
  { city: "Курчатов", vk: 76500, tg: 28900, youtube: 19800, engagement: 6.8 },
  { city: "Нововоронеж", vk: 65400, tg: 24500, youtube: 16200, engagement: 7.5 },
  { city: "Заречный", vk: 54300, tg: 19800, youtube: 12500, engagement: 8.2 },
  { city: "Десногорск", vk: 43200, tg: 15200, youtube: 9800, engagement: 6.5 },
  { city: "Полярные Зори", vk: 32100, tg: 11500, youtube: 7200, engagement: 7.8 },
];

const engagementData = [
  { name: "Лайки", value: 45, color: "hsl(var(--chart-1))" },
  { name: "Комментарии", value: 25, color: "hsl(var(--chart-2))" },
  { name: "Репосты", value: 20, color: "hsl(var(--chart-3))" },
  { name: "Сохранения", value: 10, color: "hsl(var(--chart-4))" },
];

interface SocialAnalyticsPageProps {
  userRole?: "super_admin" | "smm";
}

export default function SocialAnalyticsPage({ userRole = "super_admin" }: SocialAnalyticsPageProps) {
  const [selectedYear, setSelectedYear] = useState("2024");
  const [activeTab, setActiveTab] = useState("overview");

  const totalVK = monthlyData.reduce((sum, m) => sum + m.vk, 0);
  const totalTG = monthlyData.reduce((sum, m) => sum + m.tg, 0);
  const totalYoutube = monthlyData.reduce((sum, m) => sum + m.youtube, 0);
  const totalViews = totalVK + totalTG + totalYoutube;

  const lastMonthVK = monthlyData[monthlyData.length - 1].vk;
  const prevMonthVK = monthlyData[monthlyData.length - 2].vk;
  const vkGrowth = ((lastMonthVK - prevMonthVK) / prevMonthVK * 100).toFixed(1);

  const lastMonthTG = monthlyData[monthlyData.length - 1].tg;
  const prevMonthTG = monthlyData[monthlyData.length - 2].tg;
  const tgGrowth = ((lastMonthTG - prevMonthTG) / prevMonthTG * 100).toFixed(1);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Аналитика соц. сетей</h1>
          <p className="text-muted-foreground">Статистика ВКонтакте, Telegram и YouTube</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-[120px]" data-testid="select-year">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
              <SelectItem value="2022">2022</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" data-testid="button-export-analytics">
            <BarChart3 className="h-4 w-4 mr-2" />
            Экспорт
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-blue-500/10 text-blue-500">
              <SiVk className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="text-2xl font-bold font-mono">{formatNumber(totalVK)}</p>
              <div className="flex items-center gap-2">
                <p className="text-sm text-muted-foreground">ВКонтакте</p>
                <Badge variant="secondary" className="text-xs">
                  <TrendingUp className="h-3 w-3 mr-1 text-chart-2" />
                  +{vkGrowth}%
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-sky-500/10 text-sky-500">
              <SiTelegram className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="text-2xl font-bold font-mono">{formatNumber(totalTG)}</p>
              <div className="flex items-center gap-2">
                <p className="text-sm text-muted-foreground">Telegram</p>
                <Badge variant="secondary" className="text-xs">
                  <TrendingUp className="h-3 w-3 mr-1 text-chart-2" />
                  +{tgGrowth}%
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-red-500/10 text-red-500">
              <SiYoutube className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="text-2xl font-bold font-mono">{formatNumber(totalYoutube)}</p>
              <p className="text-sm text-muted-foreground">YouTube</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <Eye className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono">{formatNumber(totalViews)}</p>
              <p className="text-sm text-muted-foreground">Всего просмотров</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">Обзор</TabsTrigger>
          <TabsTrigger value="platforms" data-testid="tab-platforms">По платформам</TabsTrigger>
          {userRole === "super_admin" && (
            <TabsTrigger value="cities" data-testid="tab-cities">По городам</TabsTrigger>
          )}
          <TabsTrigger value="engagement" data-testid="tab-engagement">Вовлечённость</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Динамика просмотров по месяцам</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-xs" />
                    <YAxis className="text-xs" tickFormatter={(v) => formatNumber(v)} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px"
                      }}
                      formatter={(value: number) => formatNumber(value)}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="vk" name="ВКонтакте" stackId="1" stroke="hsl(210, 100%, 50%)" fill="hsl(210, 100%, 50%)" fillOpacity={0.3} />
                    <Area type="monotone" dataKey="tg" name="Telegram" stackId="1" stroke="hsl(195, 100%, 50%)" fill="hsl(195, 100%, 50%)" fillOpacity={0.3} />
                    <Area type="monotone" dataKey="youtube" name="YouTube" stackId="1" stroke="hsl(0, 100%, 50%)" fill="hsl(0, 100%, 50%)" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="platforms" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center gap-3">
                <SiVk className="h-5 w-5 text-blue-500" />
                <CardTitle>ВКонтакте</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">Подписчики</p>
                    <p className="text-xl font-bold font-mono">48.5K</p>
                  </div>
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">Охват за месяц</p>
                    <p className="text-xl font-bold font-mono">{formatNumber(lastMonthVK)}</p>
                  </div>
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">Посты за месяц</p>
                    <p className="text-xl font-bold font-mono">127</p>
                  </div>
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">ER</p>
                    <p className="text-xl font-bold font-mono">7.8%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center gap-3">
                <SiTelegram className="h-5 w-5 text-sky-500" />
                <CardTitle>Telegram</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">Подписчики</p>
                    <p className="text-xl font-bold font-mono">15.2K</p>
                  </div>
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">Охват за месяц</p>
                    <p className="text-xl font-bold font-mono">{formatNumber(lastMonthTG)}</p>
                  </div>
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">Посты за месяц</p>
                    <p className="text-xl font-bold font-mono">85</p>
                  </div>
                  <div className="p-3 rounded-md bg-muted">
                    <p className="text-sm text-muted-foreground">ER</p>
                    <p className="text-xl font-bold font-mono">12.4%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {userRole === "super_admin" && (
          <TabsContent value="cities" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Статистика по городам</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={cityStats} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                      <XAxis type="number" tickFormatter={(v) => formatNumber(v)} />
                      <YAxis type="category" dataKey="city" width={120} />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                        formatter={(value: number) => formatNumber(value)}
                      />
                      <Legend />
                      <Bar dataKey="vk" name="ВК" fill="hsl(210, 100%, 50%)" />
                      <Bar dataKey="tg" name="TG" fill="hsl(195, 100%, 50%)" />
                      <Bar dataKey="youtube" name="YT" fill="hsl(0, 100%, 50%)" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        <TabsContent value="engagement" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Структура вовлечённости</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={engagementData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {engagementData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px"
                        }}
                      />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Топ метрики</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-md bg-muted">
                  <div className="flex items-center gap-3">
                    <Heart className="h-5 w-5 text-red-500" />
                    <span>Лайки</span>
                  </div>
                  <span className="font-bold font-mono">245.8K</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-muted">
                  <div className="flex items-center gap-3">
                    <MessageCircle className="h-5 w-5 text-blue-500" />
                    <span>Комментарии</span>
                  </div>
                  <span className="font-bold font-mono">18.2K</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-muted">
                  <div className="flex items-center gap-3">
                    <Share2 className="h-5 w-5 text-green-500" />
                    <span>Репосты</span>
                  </div>
                  <span className="font-bold font-mono">12.5K</span>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-muted">
                  <div className="flex items-center gap-3">
                    <Users className="h-5 w-5 text-purple-500" />
                    <span>Новые подписчики</span>
                  </div>
                  <span className="font-bold font-mono">+8.7K</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
