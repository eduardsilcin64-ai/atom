import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import EventCard from "@/components/EventCard";
import { Plus, Search, Calendar, Filter } from "lucide-react";

type EventStatus = 
  | "calendar_draft" 
  | "calendar_pending" 
  | "calendar_approved" 
  | "budget_draft" 
  | "budget_pending"
  | "budget_approved"
  | "completed";

const mockEvents: { id: string; title: string; city: string; date: Date; discipline: string; status: EventStatus }[] = [
  { id: "e1", title: "Кубок ATOM.GAME по CS2", city: "Балаково", date: new Date(2026, 2, 15), discipline: "Counter-Strike 2", status: "budget_approved" },
  { id: "e2", title: "Турнир по FIFA 24", city: "Обнинск", date: new Date(2026, 2, 20), discipline: "FIFA 24", status: "budget_approved" },
  { id: "e3", title: "Чемпионат по Dota 2", city: "Сосновый Бор", date: new Date(2026, 2, 28), discipline: "Dota 2", status: "calendar_approved" },
  { id: "e4", title: "Лига Valorant", city: "Курчатов", date: new Date(2026, 3, 5), discipline: "Valorant", status: "calendar_pending" },
  { id: "e5", title: "Турнир по League of Legends", city: "Нововоронеж", date: new Date(2026, 3, 12), discipline: "League of Legends", status: "budget_pending" },
  { id: "e6", title: "Кибер-вечер Mobile Legends", city: "Заречный", date: new Date(2026, 3, 18), discipline: "Mobile Legends", status: "calendar_approved" },
  { id: "e7", title: "Чемпионат по Apex Legends", city: "Балаково", date: new Date(2026, 4, 1), discipline: "Apex Legends", status: "completed" },
  { id: "e8", title: "Турнир по Fortnite", city: "Обнинск", date: new Date(2026, 1, 15), discipline: "Fortnite", status: "completed" },
];

interface EventsPageProps {
  onNavigateEvent?: (eventId: string) => void;
  userRole?: "super_admin" | "city_org" | "smm";
}

export default function EventsPage({ onNavigateEvent, userRole = "super_admin" }: EventsPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [cityFilter, setCityFilter] = useState<string>("all");

  const cities = Array.from(new Set(mockEvents.map(e => e.city)));

  const filteredEvents = mockEvents.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.discipline.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || event.status === statusFilter;
    const matchesCity = cityFilter === "all" || event.city === cityFilter;
    return matchesSearch && matchesStatus && matchesCity;
  });

  const upcomingCount = mockEvents.filter(e => e.status !== "completed").length;
  const completedCount = mockEvents.filter(e => e.status === "completed").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Все события</h1>
          <p className="text-muted-foreground">Список всех мероприятий проекта ATOM.GAME</p>
        </div>
        {userRole !== "smm" && (
          <Button data-testid="button-create-event">
            <Plus className="h-4 w-4 mr-2" />
            Создать событие
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <Calendar className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{mockEvents.length}</p>
              <p className="text-sm text-muted-foreground">Всего событий</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-2/10 text-chart-2">
              <Calendar className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{upcomingCount}</p>
              <p className="text-sm text-muted-foreground">Предстоящих</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-4/10 text-chart-4">
              <Calendar className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{completedCount}</p>
              <p className="text-sm text-muted-foreground">Завершённых</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск событий..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-events"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]" data-testid="select-status-filter">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Статус" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все статусы</SelectItem>
            <SelectItem value="calendar_pending">Календарь на утверждении</SelectItem>
            <SelectItem value="budget_pending">Бюджет на утверждении</SelectItem>
            <SelectItem value="calendar_approved">Календарь подтверждён</SelectItem>
            <SelectItem value="budget_approved">Бюджет подтверждён</SelectItem>
            <SelectItem value="completed">Завершён</SelectItem>
          </SelectContent>
        </Select>
        {userRole === "super_admin" && (
          <Select value={cityFilter} onValueChange={setCityFilter}>
            <SelectTrigger className="w-[180px]" data-testid="select-city-filter">
              <SelectValue placeholder="Город" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все города</SelectItem>
              {cities.map(city => (
                <SelectItem key={city} value={city}>{city}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      <div className="space-y-3">
        {filteredEvents.map((event) => (
          <EventCard
            key={event.id}
            {...event}
            compact
            onClick={() => onNavigateEvent?.(event.id)}
          />
        ))}
      </div>

      {filteredEvents.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">События не найдены</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
