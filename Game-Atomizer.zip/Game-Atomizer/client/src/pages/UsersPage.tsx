import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Users, UserCheck, UserX, MoreVertical, Mail, MapPin } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type UserRole = "super_admin" | "city_org" | "smm";

interface MockUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  city?: string;
  isActive: boolean;
  lastActive: Date;
}

const mockUsers: MockUser[] = [
  { id: "1", name: "Администратор", email: "admin@atom.game", role: "super_admin", isActive: true, lastActive: new Date() },
  { id: "2", name: "Иванов Иван Иванович", email: "ivanov@atom.game", role: "city_org", city: "Балаково", isActive: true, lastActive: new Date(Date.now() - 2 * 60 * 60 * 1000) },
  { id: "3", name: "Петров Пётр Петрович", email: "petrov@atom.game", role: "city_org", city: "Обнинск", isActive: true, lastActive: new Date(Date.now() - 24 * 60 * 60 * 1000) },
  { id: "4", name: "Сидоров Сергей Сергеевич", email: "sidorov@atom.game", role: "city_org", city: "Курчатов", isActive: true, lastActive: new Date(Date.now() - 48 * 60 * 60 * 1000) },
  { id: "5", name: "Козлова Анна Викторовна", email: "kozlova@atom.game", role: "city_org", city: "Сосновый Бор", isActive: true, lastActive: new Date(Date.now() - 12 * 60 * 60 * 1000) },
  { id: "6", name: "Морозов Дмитрий Константинович", email: "morozov@atom.game", role: "city_org", city: "Нововоронеж", isActive: false, lastActive: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
  { id: "7", name: "SMM Менеджер 1", email: "smm1@atom.game", role: "smm", isActive: true, lastActive: new Date(Date.now() - 1 * 60 * 60 * 1000) },
  { id: "8", name: "SMM Менеджер 2", email: "smm2@atom.game", role: "smm", isActive: true, lastActive: new Date(Date.now() - 3 * 60 * 60 * 1000) },
];

const roleLabels: Record<UserRole, string> = {
  super_admin: "Администратор",
  city_org: "Организатор города",
  smm: "SMM-специалист",
};

const roleBadgeVariants: Record<UserRole, "default" | "secondary" | "outline"> = {
  super_admin: "default",
  city_org: "secondary",
  smm: "outline",
};

export default function UsersPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");

  const filteredUsers = mockUsers.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (user.city?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false);
    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const activeCount = mockUsers.filter(u => u.isActive).length;
  const cityOrgCount = mockUsers.filter(u => u.role === "city_org").length;
  const smmCount = mockUsers.filter(u => u.role === "smm").length;

  const formatLastActive = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    
    if (hours < 1) return "Сейчас онлайн";
    if (hours < 24) return `${hours}ч назад`;
    return `${days}д назад`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold">Пользователи</h1>
          <p className="text-muted-foreground">Управление пользователями системы</p>
        </div>
        <Button data-testid="button-add-user">
          <Plus className="h-4 w-4 mr-2" />
          Добавить пользователя
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{mockUsers.length}</p>
              <p className="text-sm text-muted-foreground">Всего</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-2/10 text-chart-2">
              <UserCheck className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{activeCount}</p>
              <p className="text-sm text-muted-foreground">Активных</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-3/10 text-chart-3">
              <MapPin className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{cityOrgCount}</p>
              <p className="text-sm text-muted-foreground">Организаторов</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-4/10 text-chart-4">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold">{smmCount}</p>
              <p className="text-sm text-muted-foreground">SMM</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Поиск пользователей..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search-users"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-[200px]" data-testid="select-role-filter">
            <SelectValue placeholder="Все роли" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Все роли</SelectItem>
            <SelectItem value="super_admin">Администраторы</SelectItem>
            <SelectItem value="city_org">Организаторы</SelectItem>
            <SelectItem value="smm">SMM-специалисты</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {filteredUsers.map((user) => (
              <div 
                key={user.id}
                className="flex items-center justify-between gap-4 p-4 hover-elevate"
                data-testid={`user-row-${user.id}`}
              >
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarFallback>
                      {user.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium">{user.name}</span>
                      <Badge variant={roleBadgeVariants[user.role]}>
                        {roleLabels[user.role]}
                      </Badge>
                      {!user.isActive && (
                        <Badge variant="outline" className="text-muted-foreground">
                          <UserX className="h-3 w-3 mr-1" />
                          Неактивен
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground flex-wrap">
                      <span className="flex items-center gap-1">
                        <Mail className="h-3 w-3" />
                        {user.email}
                      </span>
                      {user.city && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {user.city}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-muted-foreground hidden sm:block">
                    {formatLastActive(user.lastActive)}
                  </span>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" data-testid={`button-user-menu-${user.id}`}>
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Редактировать</DropdownMenuItem>
                      <DropdownMenuItem>Сбросить пароль</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive">Деактивировать</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {filteredUsers.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">Пользователи не найдены</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
