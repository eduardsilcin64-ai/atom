import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface EventCreateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit?: (data: EventFormData) => void;
  cityName?: string;
}

interface EventFormData {
  title: string;
  discipline: string;
  date: Date | undefined;
  format: string;
  description: string;
}

const disciplines = [
  "Counter-Strike 2",
  "Dota 2",
  "Valorant",
  "League of Legends",
  "FIFA 24",
  "Mobile Legends",
  "PUBG Mobile",
  "Другое",
];

export default function EventCreateDialog({ open, onOpenChange, onSubmit, cityName }: EventCreateDialogProps) {
  const [formData, setFormData] = useState<EventFormData>({
    title: "",
    discipline: "",
    date: undefined,
    format: "",
    description: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit?.(formData);
    onOpenChange(false);
    setFormData({ title: "", discipline: "", date: undefined, format: "", description: "" });
  };

  const handleSaveDraft = () => {
    console.log("Save draft:", formData);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Новое событие</DialogTitle>
          <DialogDescription>
            Создайте черновик календарного плана для {cityName || "города"}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Название события *</Label>
            <Input
              id="title"
              placeholder="Например: Кубок ATOM.GAME по CS2"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
              data-testid="input-event-title"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="discipline">Дисциплина *</Label>
            <Select 
              value={formData.discipline} 
              onValueChange={(v) => setFormData({ ...formData, discipline: v })}
            >
              <SelectTrigger data-testid="select-discipline">
                <SelectValue placeholder="Выберите дисциплину" />
              </SelectTrigger>
              <SelectContent>
                {disciplines.map((d) => (
                  <SelectItem key={d} value={d}>{d}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Дата проведения *</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formData.date && "text-muted-foreground"
                  )}
                  data-testid="button-select-date"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.date ? format(formData.date, "PPP", { locale: ru }) : "Выберите дату"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formData.date}
                  onSelect={(date) => setFormData({ ...formData, date })}
                  initialFocus
                  locale={ru}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="format">Формат турнира</Label>
            <Input
              id="format"
              placeholder="Например: 5v5, Single Elimination"
              value={formData.format}
              onChange={(e) => setFormData({ ...formData, format: e.target.value })}
              data-testid="input-event-format"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Описание</Label>
            <Textarea
              id="description"
              placeholder="Краткое описание события..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
              data-testid="input-event-description"
            />
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button type="button" variant="outline" onClick={handleSaveDraft} data-testid="button-save-draft">
              Сохранить черновик
            </Button>
            <Button type="submit" disabled={!formData.title || !formData.discipline || !formData.date} data-testid="button-submit-calendar">
              Отправить на утверждение
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
