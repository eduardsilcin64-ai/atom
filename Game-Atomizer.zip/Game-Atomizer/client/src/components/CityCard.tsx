import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import BudgetProgress from "./BudgetProgress";
import { MoreVertical, MapPin, Calendar, AlertTriangle } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

interface CityCardProps {
  id: string;
  name: string;
  organizerName?: string;
  eventsCount: number;
  pendingEvents: number;
  budget: {
    total: number;
    approved: number;
    spent: number;
  };
  hasWarnings?: boolean;
  isActive?: boolean;
  onClick?: () => void;
  onManage?: () => void;
}

export default function CityCard({
  id,
  name,
  organizerName,
  eventsCount,
  pendingEvents,
  budget,
  hasWarnings,
  isActive = true,
  onClick,
  onManage,
}: CityCardProps) {
  return (
    <Card 
      className={cn(
        "transition-all",
        onClick && "cursor-pointer hover-elevate",
        !isActive && "opacity-60"
      )}
      data-testid={`city-card-${id}`}
    >
      <CardHeader className="flex flex-row items-start justify-between gap-2 pb-2">
        <div className="flex items-center gap-2 flex-wrap">
          <MapPin className="h-4 w-4 text-muted-foreground" />
          <CardTitle 
            className="text-lg cursor-pointer" 
            onClick={onClick}
            data-testid={`link-city-${id}`}
          >
            {name}
          </CardTitle>
          {hasWarnings && (
            <AlertTriangle className="h-4 w-4 text-chart-4" />
          )}
          {!isActive && (
            <Badge variant="secondary" className="text-xs">Неактивен</Badge>
          )}
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" data-testid={`button-city-menu-${id}`}>
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onClick}>Открыть</DropdownMenuItem>
            <DropdownMenuItem onClick={onManage}>Управление</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent className="space-y-4">
        {organizerName && (
          <p className="text-sm text-muted-foreground">
            Организатор: <span className="text-foreground">{organizerName}</span>
          </p>
        )}
        
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span>{eventsCount} событий</span>
          </div>
          {pendingEvents > 0 && (
            <Badge variant="outline">{pendingEvents} на утверждении</Badge>
          )}
        </div>

        <BudgetProgress 
          total={budget.total}
          approved={budget.approved}
          spent={budget.spent}
          label="Бюджет 2026"
        />
      </CardContent>
    </Card>
  );
}
