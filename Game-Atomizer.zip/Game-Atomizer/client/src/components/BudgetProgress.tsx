import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface BudgetProgressProps {
  total: number;
  spent: number;
  approved: number;
  label?: string;
  showDetails?: boolean;
  className?: string;
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0,
  }).format(amount);
}

export default function BudgetProgress({ 
  total, 
  spent, 
  approved, 
  label,
  showDetails = true,
  className 
}: BudgetProgressProps) {
  const spentPercent = Math.min((spent / total) * 100, 100);
  const approvedPercent = Math.min((approved / total) * 100, 100);
  const remaining = total - approved;
  
  const getStatusColor = () => {
    if (approvedPercent >= 100) return "text-destructive";
    if (approvedPercent >= 85) return "text-chart-4";
    return "text-chart-2";
  };

  return (
    <div className={cn("space-y-2", className)}>
      {label && (
        <div className="flex items-center justify-between gap-2">
          <span className="text-sm font-medium">{label}</span>
          <span className={cn("text-sm font-mono font-semibold", getStatusColor())}>
            {approvedPercent.toFixed(0)}%
          </span>
        </div>
      )}
      
      <div className="relative">
        <Progress value={approvedPercent} className="h-2" />
      </div>
      
      {showDetails && (
        <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
          <div>
            <span className="block text-foreground font-mono font-medium">
              {formatCurrency(total)}
            </span>
            <span>Лимит</span>
          </div>
          <div>
            <span className="block text-foreground font-mono font-medium">
              {formatCurrency(approved)}
            </span>
            <span>Одобрено</span>
          </div>
          <div>
            <span className={cn("block font-mono font-medium", remaining < 0 ? "text-destructive" : "text-chart-2")}>
              {formatCurrency(remaining)}
            </span>
            <span>Остаток</span>
          </div>
        </div>
      )}
    </div>
  );
}
