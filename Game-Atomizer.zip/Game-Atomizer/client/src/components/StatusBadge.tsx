import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

type EventStatus = 
  | "calendar_draft" 
  | "calendar_pending" 
  | "calendar_approved" 
  | "budget_draft" 
  | "budget_pending"
  | "budget_approved"
  | "completed";

type BudgetStatus = "within_limit" | "approaching_limit" | "exceeded";
type DeadlineStatus = "upcoming" | "due_soon" | "overdue" | "completed";

interface StatusBadgeProps {
  status: EventStatus | BudgetStatus | DeadlineStatus;
  className?: string;
}

const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  calendar_draft: { label: "Черновик", variant: "secondary" },
  calendar_pending: { label: "На утверждении", variant: "outline" },
  calendar_approved: { label: "Календарь утверждён", variant: "default" },
  budget_draft: { label: "Бюджет: черновик", variant: "secondary" },
  budget_pending: { label: "Бюджет на утверждении", variant: "outline" },
  budget_approved: { label: "Бюджет утверждён", variant: "default" },
  completed: { label: "Завершено", variant: "default" },
  within_limit: { label: "В норме", variant: "default" },
  approaching_limit: { label: "Приближается к лимиту", variant: "outline" },
  exceeded: { label: "Превышен", variant: "destructive" },
  upcoming: { label: "Предстоит", variant: "secondary" },
  due_soon: { label: "Скоро дедлайн", variant: "outline" },
  overdue: { label: "Просрочено", variant: "destructive" },
};

export default function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status] || { label: status, variant: "secondary" as const };
  
  return (
    <Badge 
      variant={config.variant} 
      className={cn("text-xs whitespace-nowrap", className)}
    >
      {config.label}
    </Badge>
  );
}
