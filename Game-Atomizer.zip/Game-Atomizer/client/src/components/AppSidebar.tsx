import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { 
  LayoutDashboard, 
  Calendar, 
  Wallet, 
  CheckSquare,
  MapPin,
  Users,
  BarChart3,
  Settings,
  LogOut,
  Bell,
  Atom
} from "lucide-react";

type UserRole = "super_admin" | "city_org" | "smm";

interface AppSidebarProps {
  role: UserRole;
  userName: string;
  cityName?: string;
  pendingCount?: number;
}

interface MenuItem {
  title: string;
  icon: typeof LayoutDashboard;
  path: string;
  badge?: boolean;
}

const superAdminMenu: MenuItem[] = [
  { title: "Дашборд", icon: LayoutDashboard, path: "/" },
  { title: "Города", icon: MapPin, path: "/cities" },
  { title: "Все события", icon: Calendar, path: "/events" },
  { title: "На утверждение", icon: CheckSquare, path: "/approvals", badge: true },
  { title: "Аналитика", icon: BarChart3, path: "/analytics" },
  { title: "Пользователи", icon: Users, path: "/users" },
];

const cityOrgMenu: MenuItem[] = [
  { title: "Мой город", icon: LayoutDashboard, path: "/" },
  { title: "События", icon: Calendar, path: "/events" },
  { title: "Бюджет", icon: Wallet, path: "/budget" },
  { title: "Уведомления", icon: Bell, path: "/notifications" },
];

const smmMenu: MenuItem[] = [
  { title: "Лента событий", icon: Calendar, path: "/" },
  { title: "Мои задачи", icon: CheckSquare, path: "/tasks" },
  { title: "Медиа", icon: BarChart3, path: "/media" },
  { title: "Отчёт соц. сетей", icon: BarChart3, path: "/analytics" },
];

const roleLabels: Record<UserRole, string> = {
  super_admin: "Главный организатор",
  city_org: "Городской организатор",
  smm: "SMM-специалист",
};

export default function AppSidebar({ role, userName, cityName, pendingCount = 0 }: AppSidebarProps) {
  const [location] = useLocation();
  
  const menuItems = role === "super_admin" 
    ? superAdminMenu 
    : role === "city_org" 
      ? cityOrgMenu 
      : smmMenu;

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary text-primary-foreground">
            <Atom className="h-6 w-6" />
          </div>
          <div>
            <h1 className="font-bold text-lg">ATOM.GAME</h1>
            <p className="text-xs text-muted-foreground">Панель управления</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Меню</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => {
                const isActive = location === item.path || 
                  (item.path !== "/" && location.startsWith(item.path));
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      asChild 
                      isActive={isActive}
                      data-testid={`nav-${item.path.replace(/\//g, '') || 'home'}`}
                    >
                      <Link href={item.path}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge && pendingCount > 0 && (
                          <Badge variant="destructive" className="ml-auto text-xs">
                            {pendingCount}
                          </Badge>
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Настройки</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild data-testid="nav-settings">
                  <Link href="/settings">
                    <Settings className="h-4 w-4" />
                    <span>Настройки</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <Avatar className="h-9 w-9">
            <AvatarFallback className="bg-sidebar-accent text-sidebar-accent-foreground">
              {userName.split(' ').map(n => n[0]).join('').toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{userName}</p>
            <div className="flex items-center gap-1 flex-wrap">
              <span className="text-xs text-muted-foreground">{roleLabels[role]}</span>
              {cityName && (
                <Badge variant="secondary" className="text-xs">{cityName}</Badge>
              )}
            </div>
          </div>
          <SidebarMenuButton 
            asChild 
            className="w-auto p-2"
            data-testid="button-logout"
          >
            <button onClick={() => console.log("Logout")}>
              <LogOut className="h-4 w-4" />
            </button>
          </SidebarMenuButton>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
