import StatCard from "../StatCard";
import { Calendar, Users, Eye } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <StatCard 
        title="Всего мероприятий" 
        value={47} 
        trend={12} 
        trendLabel="vs прошлый год"
        icon={<Calendar className="h-5 w-5" />}
      />
      <StatCard 
        title="Участников" 
        value="2,847" 
        trend={-5} 
        trendLabel="vs прошлый месяц"
        icon={<Users className="h-5 w-5" />}
      />
      <StatCard 
        title="Просмотров" 
        value="156K" 
        trend={23} 
        icon={<Eye className="h-5 w-5" />}
      />
    </div>
  );
}
