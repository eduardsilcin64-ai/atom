import AppSidebar from "../AppSidebar";
import { SidebarProvider } from "@/components/ui/sidebar";

export default function AppSidebarExample() {
  return (
    <SidebarProvider>
      <div className="flex h-[500px] w-full">
        <AppSidebar 
          role="super_admin" 
          userName="Администратор" 
          pendingCount={5}
        />
        <div className="flex-1 p-4 bg-background">
          <p className="text-muted-foreground">Контент страницы</p>
        </div>
      </div>
    </SidebarProvider>
  );
}
