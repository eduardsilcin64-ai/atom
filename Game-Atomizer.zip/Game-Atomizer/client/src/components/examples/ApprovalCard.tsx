import ApprovalCard from "../ApprovalCard";

export default function ApprovalCardExample() {
  return (
    <div className="space-y-4 max-w-md">
      <ApprovalCard
        id="approval-1"
        eventTitle="Кубок ATOM.GAME по CS2"
        city="Балаково"
        type="calendar"
        eventDate={new Date(2026, 2, 15)}
        submittedAt={new Date(Date.now() - 2 * 60 * 60 * 1000)}
        onApprove={() => console.log("Approved")}
        onReject={() => console.log("Rejected")}
        onView={() => console.log("View")}
      />
      <ApprovalCard
        id="approval-2"
        eventTitle="Турнир по Dota 2"
        city="Обнинск"
        type="budget"
        eventDate={new Date(2026, 3, 10)}
        submittedAt={new Date(Date.now() - 24 * 60 * 60 * 1000)}
        budgetAmount={150000}
        onApprove={() => console.log("Approved")}
        onReject={() => console.log("Rejected")}
        onView={() => console.log("View")}
      />
    </div>
  );
}
