import CityCard from "../CityCard";

export default function CityCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl">
      <CityCard
        id="balakovo"
        name="Балаково"
        organizerName="Иванов И.И."
        eventsCount={12}
        pendingEvents={2}
        budget={{ total: 1200000, approved: 720000, spent: 450000 }}
        onClick={() => console.log("Open Balakovo")}
      />
      <CityCard
        id="obninsk"
        name="Обнинск"
        organizerName="Петров П.П."
        eventsCount={8}
        pendingEvents={0}
        budget={{ total: 800000, approved: 780000, spent: 720000 }}
        hasWarnings={true}
        onClick={() => console.log("Open Obninsk")}
      />
    </div>
  );
}
