import LoginPage from "@/pages/LoginPage";

export default function LoginPageExample() {
  return (
    <LoginPage onLogin={(email, pass) => console.log("Login:", email)} />
  );
}
