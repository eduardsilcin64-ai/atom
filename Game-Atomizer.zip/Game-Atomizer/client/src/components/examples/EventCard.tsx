import EventCard from "../EventCard";

export default function EventCardExample() {
  return (
    <div className="space-y-4 max-w-xl">
      <EventCard
        id="event-1"
        title="Кубок ATOM.GAME по CS2"
        city="Балаково"
        date={new Date(2026, 2, 15)}
        discipline="Counter-Strike 2"
        status="budget_approved"
        onClick={() => console.log("Open event")}
      />
      <EventCard
        id="event-2"
        title="Турнир по Dota 2"
        city="Обнинск"
        date={new Date(2024, 10, 20)}
        discipline="Dota 2"
        status="completed"
        participantsCount={64}
        winner="Team Nuclear"
        onClick={() => console.log("Open event")}
      />
    </div>
  );
}
