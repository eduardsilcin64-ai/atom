import CityOrgDashboard from "../dashboard/CityOrgDashboard";

export default function CityOrgDashboardExample() {
  return (
    <div className="p-6 bg-background min-h-screen">
      <CityOrgDashboard 
        onNavigateEvent={(id) => console.log("Navigate to event:", id)}
        onCreateEvent={() => console.log("Create event")}
      />
    </div>
  );
}
