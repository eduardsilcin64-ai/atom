import SMMDashboard from "../dashboard/SMMDashboard";

export default function SMMDashboardExample() {
  return (
    <div className="p-6 bg-background min-h-screen">
      <SMMDashboard 
        onNavigateEvent={(id) => console.log("Navigate to event:", id)}
      />
    </div>
  );
}
