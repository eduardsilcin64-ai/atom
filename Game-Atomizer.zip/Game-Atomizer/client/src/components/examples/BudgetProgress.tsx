import BudgetProgress from "../BudgetProgress";

export default function BudgetProgressExample() {
  return (
    <div className="w-full max-w-md space-y-6">
      <BudgetProgress 
        total={1200000} 
        spent={450000} 
        approved={720000} 
        label="Балаково 2026"
      />
      <BudgetProgress 
        total={800000} 
        spent={750000} 
        approved={780000} 
        label="Обнинск 2026"
      />
    </div>
  );
}
