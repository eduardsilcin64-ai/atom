import { useState } from "react";
import { Button } from "@/components/ui/button";
import EventCreateDialog from "../EventCreateDialog";

export default function EventCreateDialogExample() {
  const [open, setOpen] = useState(true);
  
  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)}>Открыть форму</Button>
      <EventCreateDialog 
        open={open} 
        onOpenChange={setOpen}
        cityName="Балаково"
        onSubmit={(data) => console.log("Submit:", data)}
      />
    </div>
  );
}
