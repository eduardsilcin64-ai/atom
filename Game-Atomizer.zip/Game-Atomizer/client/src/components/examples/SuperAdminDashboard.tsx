import SuperAdminDashboard from "../dashboard/SuperAdminDashboard";

export default function SuperAdminDashboardExample() {
  return (
    <div className="p-6 bg-background min-h-screen">
      <SuperAdminDashboard 
        onNavigateCity={(id) => console.log("Navigate to city:", id)}
        onNavigateEvent={(id) => console.log("Navigate to event:", id)}
      />
    </div>
  );
}
