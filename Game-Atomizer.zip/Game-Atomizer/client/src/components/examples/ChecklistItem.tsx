import ChecklistItem from "../ChecklistItem";

export default function ChecklistItemExample() {
  return (
    <div className="space-y-2 max-w-md">
      <ChecklistItem
        id="task-1"
        title="Опубликовать анонс в соцсетях"
        assignee="smm"
        dueDate={new Date(Date.now() + 3 * 24 * 60 * 60 * 1000)}
        completed={false}
        onToggle={(v) => console.log("Toggle:", v)}
      />
      <ChecklistItem
        id="task-2"
        title="Подготовить регистрационную форму"
        assignee="city_org"
        dueDate={new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)}
        completed={false}
        onToggle={(v) => console.log("Toggle:", v)}
      />
      <ChecklistItem
        id="task-3"
        title="Согласовать призовой фонд"
        assignee="city_org"
        dueDate={new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)}
        completed={true}
        onToggle={(v) => console.log("Toggle:", v)}
      />
    </div>
  );
}
