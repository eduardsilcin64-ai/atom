import EventDetailPage from "../dashboard/EventDetailPage";

export default function EventDetailPageExample() {
  return (
    <div className="p-6 bg-background min-h-screen">
      <EventDetailPage 
        eventId="e1"
        userRole="city_org"
        onBack={() => console.log("Go back")}
      />
    </div>
  );
}
