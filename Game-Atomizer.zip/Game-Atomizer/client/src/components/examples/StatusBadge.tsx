import StatusBadge from "../StatusBadge";

export default function StatusBadgeExample() {
  return (
    <div className="flex flex-wrap gap-2">
      <StatusBadge status="calendar_draft" />
      <StatusBadge status="calendar_approved" />
      <StatusBadge status="budget_pending" />
      <StatusBadge status="budget_approved" />
      <StatusBadge status="overdue" />
      <StatusBadge status="within_limit" />
    </div>
  );
}
