import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import StatusBadge from "./StatusBadge";
import { Calendar, MapPin, Users, Trophy, MoreVertical } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { cn } from "@/lib/utils";

type EventStatus = 
  | "calendar_draft" 
  | "calendar_pending" 
  | "calendar_approved" 
  | "budget_draft" 
  | "budget_pending"
  | "budget_approved"
  | "completed";

interface EventCardProps {
  id: string;
  title: string;
  city: string;
  date: Date;
  discipline: string;
  status: EventStatus;
  participantsCount?: number;
  winner?: string;
  onClick?: () => void;
  onEdit?: () => void;
  compact?: boolean;
}

export default function EventCard({
  id,
  title,
  city,
  date,
  discipline,
  status,
  participantsCount,
  winner,
  onClick,
  onEdit,
  compact = false,
}: EventCardProps) {
  const isPast = date < new Date();

  return (
    <Card 
      className={cn(
        "transition-all",
        onClick && "cursor-pointer hover-elevate"
      )}
      data-testid={`event-card-${id}`}
    >
      <CardHeader className={cn("flex flex-row items-start justify-between gap-2", compact ? "pb-2" : "pb-3")}>
        <div className="space-y-1 min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <CardTitle 
              className={cn("cursor-pointer", compact ? "text-base" : "text-lg")} 
              onClick={onClick}
              data-testid={`link-event-${id}`}
            >
              {title}
            </CardTitle>
            <StatusBadge status={status} />
          </div>
          <div className="flex items-center gap-3 text-sm text-muted-foreground flex-wrap">
            <span className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              {city}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {format(date, "d MMM yyyy", { locale: ru })}
            </span>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" data-testid={`button-event-menu-${id}`}>
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onClick}>Подробнее</DropdownMenuItem>
            <DropdownMenuItem onClick={onEdit}>Редактировать</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      
      {!compact && (
        <CardContent className="space-y-2">
          <div className="flex items-center gap-4 text-sm flex-wrap">
            <span className="text-muted-foreground">
              Дисциплина: <span className="text-foreground">{discipline}</span>
            </span>
            {participantsCount !== undefined && (
              <span className="flex items-center gap-1 text-muted-foreground">
                <Users className="h-3 w-3" />
                {participantsCount} участников
              </span>
            )}
          </div>
          {isPast && winner && (
            <div className="flex items-center gap-1 text-sm">
              <Trophy className="h-3 w-3 text-chart-4" />
              <span className="text-muted-foreground">Победитель:</span>
              <span className="font-medium">{winner}</span>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  );
}
