import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import StatusBadge from "../StatusBadge";
import { Calendar, MapPin, Trophy, Users, Upload, Search, Eye, Link2, FileText, Plus, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Event, SmmReport, City } from "@shared/schema";

interface SMMDashboardProps {
  onNavigateEvent?: (eventId: string) => void;
  currentUserId?: string;
}

export default function SMMDashboard({ onNavigateEvent, currentUserId }: SMMDashboardProps) {
  const [activeTab, setActiveTab] = useState("events");
  const [searchQuery, setSearchQuery] = useState("");
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [reportTitle, setReportTitle] = useState("");
  const [reportContent, setReportContent] = useState("");
  const { toast } = useToast();

  const { data: events = [], isLoading: eventsLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const { data: cities = [] } = useQuery<City[]>({
    queryKey: ["/api/cities"],
  });

  const smmReportsUrl = currentUserId ? `/api/smm-reports?userId=${currentUserId}` : "/api/smm-reports";
  const { data: smmReports = [], isLoading: reportsLoading } = useQuery<SmmReport[]>({
    queryKey: [smmReportsUrl],
  });

  const createReportMutation = useMutation({
    mutationFn: async (data: { eventId: string; title: string; content: string; smmUserId: string }) => {
      return apiRequest("/api/smm-reports", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [smmReportsUrl] });
      toast({
        title: "Отчёт создан",
        description: "Ваш отчёт успешно сохранён как черновик",
      });
      setShowReportDialog(false);
      setReportTitle("");
      setReportContent("");
      setSelectedEventId(null);
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать отчёт",
        variant: "destructive",
      });
    },
  });

  const submitReportMutation = useMutation({
    mutationFn: async (reportId: string) => {
      return apiRequest(`/api/smm-reports/${reportId}/submit`, {
        method: "PATCH",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [smmReportsUrl] });
      toast({
        title: "Отчёт отправлен",
        description: "Отчёт отправлен на проверку",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить отчёт",
        variant: "destructive",
      });
    },
  });

  const getCityName = (cityId: string) => {
    const city = cities.find((c) => c.id === cityId);
    return city?.name || "Неизвестный город";
  };

  const getEventStatus = (event: Event): "upcoming" | "completed" | string => {
    if (event.status === "completed") return "completed";
    const eventDate = new Date(event.date);
    return eventDate >= new Date() ? "upcoming" : "completed";
  };

  const filteredEvents = events.filter((e) => {
    const cityName = getCityName(e.cityId);
    return (
      e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cityName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const getReportsForEvent = (eventId: string) => {
    return smmReports.filter((r) => r.eventId === eventId);
  };

  const draftReports = smmReports.filter((r) => r.status === "draft");
  const submittedReports = smmReports.filter((r) => r.status === "submitted");

  const totalViews = smmReports.reduce((sum, r) => sum + (r.views || 0), 0);
  const totalMediaCount = events.reduce((sum, e) => sum + (e.mediaLinks?.length || 0), 0);

  const handleCreateReport = () => {
    if (!selectedEventId || !reportTitle.trim() || !reportContent.trim()) {
      toast({
        title: "Заполните все поля",
        description: "Выберите событие, введите заголовок и содержание отчёта",
        variant: "destructive",
      });
      return;
    }

    createReportMutation.mutate({
      eventId: selectedEventId,
      title: reportTitle,
      content: reportContent,
      smmUserId: currentUserId || "unknown",
    });
  };

  const openReportDialog = (eventId: string) => {
    setSelectedEventId(eventId);
    setShowReportDialog(true);
  };

  if (eventsLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">SMM Панель</h1>
          <p className="text-muted-foreground">Управление контентом и медиа</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-12 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-smm-title">SMM Панель</h1>
        <p className="text-muted-foreground">Управление контентом и медиа</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-destructive/10 text-destructive">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold" data-testid="text-draft-reports-count">{draftReports.length}</p>
              <p className="text-sm text-muted-foreground">Черновиков</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-chart-2/10 text-chart-2">
              <Eye className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold font-mono" data-testid="text-total-views">
                {totalViews > 1000 ? `${(totalViews / 1000).toFixed(1)}K` : totalViews}
              </p>
              <p className="text-sm text-muted-foreground">Просмотров всего</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-md bg-primary/10 text-primary">
              <Upload className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold" data-testid="text-media-count">{totalMediaCount}</p>
              <p className="text-sm text-muted-foreground">Медиафайлов</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="events" data-testid="tab-events">
            Лента событий
          </TabsTrigger>
          <TabsTrigger value="reports" data-testid="tab-reports">
            Мои отчёты
            {draftReports.length > 0 && (
              <span className="ml-1.5 px-1.5 py-0.5 text-xs rounded-full bg-destructive text-destructive-foreground">
                {draftReports.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="events" className="space-y-4 mt-6">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Поиск событий..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-events"
              />
            </div>
          </div>

          {filteredEvents.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Нет событий</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredEvents.map((event) => {
                const eventReports = getReportsForEvent(event.id);
                const eventStatus = getEventStatus(event);
                const cityName = getCityName(event.cityId);

                return (
                  <Card
                    key={event.id}
                    className="hover-elevate cursor-pointer"
                    onClick={() => onNavigateEvent?.(event.id)}
                    data-testid={`event-card-smm-${event.id}`}
                  >
                    <CardContent className="p-4 space-y-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-semibold" data-testid={`text-event-title-${event.id}`}>
                              {event.title}
                            </h3>
                            <StatusBadge status={eventStatus} />
                          </div>
                          <div className="flex items-center gap-3 text-sm text-muted-foreground flex-wrap">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {cityName}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {format(new Date(event.date), "d MMM yyyy", { locale: ru })}
                            </span>
                          </div>
                        </div>
                        <Badge variant="secondary">
                          {eventReports.length} отчётов
                        </Badge>
                      </div>

                      <div className="flex items-center gap-4 text-sm flex-wrap">
                        {event.participantsCount && event.participantsCount > 0 && (
                          <span className="flex items-center gap-1 text-muted-foreground">
                            <Users className="h-3 w-3" />
                            {event.participantsCount} участников
                          </span>
                        )}
                        {event.winner && (
                          <span className="flex items-center gap-1">
                            <Trophy className="h-3 w-3 text-chart-4" />
                            {event.winner}
                          </span>
                        )}
                        {event.registrationUrl && (
                          <span className="flex items-center gap-1 text-primary">
                            <Link2 className="h-3 w-3" />
                            Регистрация открыта
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            openReportDialog(event.id);
                          }}
                          data-testid={`button-create-report-${event.id}`}
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Создать отчёт
                        </Button>
                        <Button size="sm" variant="outline" data-testid={`button-upload-media-${event.id}`}>
                          <Upload className="h-3 w-3 mr-1" />
                          Медиа ({event.mediaLinks?.length || 0})
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="reports" className="space-y-4 mt-6">
          <h2 className="text-xl font-semibold">Мои отчёты</h2>

          {reportsLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : smmReports.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">У вас пока нет отчётов</p>
                <p className="text-sm text-muted-foreground">
                  Перейдите в ленту событий и создайте отчёт для любого мероприятия
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {smmReports.map((report) => {
                const event = events.find((e) => e.id === report.eventId);
                return (
                  <Card key={report.id} data-testid={`report-card-${report.id}`}>
                    <CardContent className="p-4 space-y-2">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-semibold">{report.title}</h3>
                          <p className="text-sm text-muted-foreground">
                            Событие: {event?.title || "Неизвестное событие"}
                          </p>
                        </div>
                        <Badge
                          variant={
                            report.status === "draft"
                              ? "secondary"
                              : report.status === "submitted"
                              ? "default"
                              : report.status === "approved"
                              ? "default"
                              : "destructive"
                          }
                        >
                          {report.status === "draft"
                            ? "Черновик"
                            : report.status === "submitted"
                            ? "На проверке"
                            : report.status === "approved"
                            ? "Одобрен"
                            : "Отклонён"}
                        </Badge>
                      </div>
                      <p className="text-sm line-clamp-2">{report.content}</p>
                      {report.status === "draft" && (
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            onClick={() => submitReportMutation.mutate(report.id)}
                            disabled={submitReportMutation.isPending}
                            data-testid={`button-submit-report-${report.id}`}
                          >
                            {submitReportMutation.isPending && (
                              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            )}
                            Отправить на проверку
                          </Button>
                        </div>
                      )}
                      {(report.views || report.likes || report.reposts) && (
                        <div className="flex items-center gap-4 text-sm text-muted-foreground pt-2">
                          {report.views && report.views > 0 && (
                            <span className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {report.views}
                            </span>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Создать отчёт</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Событие</label>
              <p className="text-sm text-muted-foreground">
                {events.find((e) => e.id === selectedEventId)?.title || "Выберите событие"}
              </p>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Заголовок</label>
              <Input
                placeholder="Заголовок отчёта..."
                value={reportTitle}
                onChange={(e) => setReportTitle(e.target.value)}
                data-testid="input-report-title"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Содержание</label>
              <Textarea
                placeholder="Опишите результаты публикации..."
                value={reportContent}
                onChange={(e) => setReportContent(e.target.value)}
                rows={5}
                data-testid="input-report-content"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReportDialog(false)}>
              Отмена
            </Button>
            <Button
              onClick={handleCreateReport}
              disabled={createReportMutation.isPending}
              data-testid="button-save-report"
            >
              {createReportMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
