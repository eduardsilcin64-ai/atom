import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import StatCard from "../StatCard";
import CityCard from "../CityCard";
import ApprovalCard from "../ApprovalCard";
import EventCard from "../EventCard";
import { Calendar, Users, Eye, TrendingUp, Plus, ChevronRight, Loader2 } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Event, City } from "@shared/schema";

interface DashboardStats {
  totalCities: number;
  totalEvents: number;
  pendingApprovals: number;
  totalBudget: number;
  spentBudget: number;
  upcomingEvents: Event[];
  recentEvents: Event[];
}

interface SuperAdminDashboardProps {
  onNavigateCity?: (cityId: string) => void;
  onNavigateEvent?: (eventId: string) => void;
  onAddCity?: () => void;
}

export default function SuperAdminDashboard({ onNavigateCity, onNavigateEvent, onAddCity }: SuperAdminDashboardProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();

  const { data: cities = [], isLoading: citiesLoading } = useQuery<City[]>({
    queryKey: ["/api/cities"],
  });

  const { data: pendingEvents = [], isLoading: pendingLoading } = useQuery<Event[]>({
    queryKey: ["/api/events/pending"],
  });

  const { data: allEvents = [] } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const approveMutation = useMutation({
    mutationFn: async (eventId: string) => {
      return apiRequest(`/api/events/${eventId}/approve`, { method: "PATCH" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Событие одобрено" });
    },
    onError: () => {
      toast({ title: "Ошибка", description: "Не удалось одобрить событие", variant: "destructive" });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (eventId: string) => {
      return apiRequest(`/api/events/${eventId}/reject`, { method: "PATCH" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      queryClient.invalidateQueries({ queryKey: ["/api/events/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Событие отклонено" });
    },
    onError: () => {
      toast({ title: "Ошибка", description: "Не удалось отклонить событие", variant: "destructive" });
    },
  });

  const isLoading = citiesLoading || pendingLoading;

  const totalBudget = cities.reduce((sum, c) => sum + Number(c.totalBudget || 0), 0);
  const spentBudget = cities.reduce((sum, c) => sum + Number(c.spentBudget || 0), 0);
  const totalEvents = allEvents.length;

  const upcomingEvents = allEvents
    .filter((e) => new Date(e.date) >= new Date() && e.status !== "completed")
    .slice(0, 5);

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 }).format(amount);

  const getCityEventsCount = (cityId: string) => {
    return allEvents.filter((e) => e.cityId === cityId).length;
  };

  const getCityPendingCount = (cityId: string) => {
    return pendingEvents.filter((e) => e.cityId === cityId).length;
  };

  const getCityName = (cityId: string) => {
    return cities.find((c) => c.id === cityId)?.name || "Неизвестный город";
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-3xl font-bold">Дашборд</h1>
            <p className="text-muted-foreground">Обзор проекта ATOM.GAME</p>
          </div>
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-40" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-dashboard-title">Дашборд</h1>
          <p className="text-muted-foreground">Обзор проекта ATOM.GAME</p>
        </div>
        <Button onClick={onAddCity} data-testid="button-add-city">
          <Plus className="h-4 w-4 mr-2" />
          Добавить город
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Всего городов"
          value={cities.length}
          icon={<TrendingUp className="h-5 w-5" />}
        />
        <StatCard
          title="Мероприятий"
          value={totalEvents}
          icon={<Calendar className="h-5 w-5" />}
        />
        <StatCard
          title="На утверждение"
          value={pendingEvents.length}
          icon={<Users className="h-5 w-5" />}
          onClick={() => setActiveTab("approvals")}
        />
        <StatCard
          title="Бюджет освоен"
          value={totalBudget > 0 ? `${((spentBudget / totalBudget) * 100).toFixed(0)}%` : "0%"}
          icon={<Eye className="h-5 w-5" />}
        />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">Обзор</TabsTrigger>
          <TabsTrigger value="approvals" data-testid="tab-approvals">
            На утверждение
            {pendingEvents.length > 0 && (
              <span className="ml-1.5 px-1.5 py-0.5 text-xs rounded-full bg-destructive text-destructive-foreground">
                {pendingEvents.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="events" data-testid="tab-events">Ближайшие события</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-xl font-semibold">Города</h2>
            <Button variant="ghost" size="sm" data-testid="button-view-all-cities">
              Все города <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          {cities.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground mb-4">Нет городов</p>
                <Button onClick={onAddCity}>
                  <Plus className="h-4 w-4 mr-2" />
                  Добавить первый город
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {cities.slice(0, 6).map((city) => (
                <CityCard
                  key={city.id}
                  id={city.id}
                  name={city.name}
                  organizerName={city.organizerName}
                  eventsCount={getCityEventsCount(city.id)}
                  pendingEvents={getCityPendingCount(city.id)}
                  budget={{
                    total: Number(city.totalBudget || 0),
                    approved: Number(city.approvedBudget || 0),
                    spent: Number(city.spentBudget || 0),
                  }}
                  onClick={() => onNavigateCity?.(city.id)}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="approvals" className="space-y-4 mt-6">
          <h2 className="text-xl font-semibold">Ожидают утверждения</h2>
          {pendingEvents.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Нет заявок на утверждение</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingEvents.map((event) => (
                <ApprovalCard
                  key={event.id}
                  id={event.id}
                  eventTitle={event.title}
                  city={getCityName(event.cityId)}
                  type={event.status === "calendar_pending" ? "calendar" : "budget"}
                  eventDate={new Date(event.date)}
                  submittedAt={event.createdAt ? new Date(event.createdAt) : new Date()}
                  budgetAmount={event.status === "budget_pending" ? Number(event.budget || 0) : undefined}
                  onApprove={() => approveMutation.mutate(event.id)}
                  onReject={() => rejectMutation.mutate(event.id)}
                  onView={() => onNavigateEvent?.(event.id)}
                  isApproving={approveMutation.isPending}
                  isRejecting={rejectMutation.isPending}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="events" className="space-y-4 mt-6">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-xl font-semibold">Ближайшие события</h2>
            <Button variant="ghost" size="sm" data-testid="button-view-all-events">
              Все события <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
          {upcomingEvents.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Нет предстоящих событий</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {upcomingEvents.map((event) => (
                <EventCard
                  key={event.id}
                  id={event.id}
                  title={event.title}
                  city={getCityName(event.cityId)}
                  date={new Date(event.date)}
                  discipline={event.discipline}
                  status={event.status}
                  compact
                  onClick={() => onNavigateEvent?.(event.id)}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
