import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import StatusBadge from "../StatusBadge";
import ChecklistItem from "../ChecklistItem";
import BudgetProgress from "../BudgetProgress";
import { ArrowLeft, Calendar, MapPin, Trophy, Users, Save, Send, Eye, Link2 } from "lucide-react";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

type EventStatus = 
  | "calendar_draft" 
  | "calendar_pending" 
  | "calendar_approved" 
  | "budget_draft" 
  | "budget_pending"
  | "budget_approved"
  | "completed";

// todo: remove mock functionality
const mockEvent = {
  id: "e1",
  title: "Кубок ATOM.GAME по CS2",
  city: "Балаково",
  date: new Date(2026, 2, 15),
  endDate: new Date(2026, 2, 16),
  discipline: "Counter-Strike 2",
  status: "budget_approved" as EventStatus,
  description: "Главный турнир сезона по Counter-Strike 2 в Балаково. Открытая квалификация для всех желающих.",
  format: "5v5, Single Elimination",
  prizePool: 50000,
  announceDeadline: new Date(2026, 2, 1),
};

const mockBudget = {
  items: [
    { category: "Призовой фонд", items: [{ name: "1 место", amount: 30000 }, { name: "2 место", amount: 15000 }, { name: "3 место", amount: 5000 }] },
    { category: "Оборудование", items: [{ name: "Аренда ПК", amount: 20000 }, { name: "Периферия", amount: 5000 }] },
    { category: "Площадка", items: [{ name: "Аренда помещения", amount: 15000 }, { name: "Декорации", amount: 8000 }] },
    { category: "Трансляция", items: [{ name: "Оператор", amount: 10000 }, { name: "Оборудование стрима", amount: 7000 }] },
  ],
  total: 115000,
  approved: true,
  approvedBy: "Главный организатор",
  approvedAt: new Date(2026, 1, 15),
};

const mockChecklist = [
  { id: "c1", title: "Опубликовать анонс", assignee: "smm" as const, dueDate: new Date(2026, 2, 1), completed: true },
  { id: "c2", title: "Открыть регистрацию", assignee: "city_org" as const, dueDate: new Date(2026, 2, 3), completed: true },
  { id: "c3", title: "Сформировать сетку турнира", assignee: "city_org" as const, dueDate: new Date(2026, 2, 13), completed: false },
  { id: "c4", title: "Подготовить площадку", assignee: "city_org" as const, dueDate: new Date(2026, 2, 14), completed: false },
  { id: "c5", title: "Провести трансляцию", assignee: "smm" as const, dueDate: new Date(2026, 2, 15), completed: false },
  { id: "c6", title: "Опубликовать пост-отчёт", assignee: "smm" as const, dueDate: new Date(2026, 2, 17), completed: false },
];

const mockReport = {
  participants: 64,
  registrations: 82,
  winner: "Team Nuclear",
  secondPlace: "Cyber Warriors",
  thirdPlace: "Phoenix Squad",
  streamViewers: 1250,
  peakViewers: 2100,
  postViews: 15000,
  mediaUploaded: 45,
};

interface EventDetailPageProps {
  eventId?: string;
  userRole?: "super_admin" | "city_org" | "smm";
  onBack?: () => void;
}

export default function EventDetailPage({ eventId, userRole = "city_org", onBack }: EventDetailPageProps) {
  const [activeTab, setActiveTab] = useState("calendar");
  
  const completedTasks = mockChecklist.filter(t => t.completed).length;
  const checklistProgress = (completedTasks / mockChecklist.length) * 100;

  const formatCurrency = (amount: number) => 
    new Intl.NumberFormat("ru-RU", { style: "currency", currency: "RUB", maximumFractionDigits: 0 }).format(amount);

  return (
    <div className="space-y-6">
      <div className="flex items-start gap-4">
        <Button variant="ghost" size="icon" onClick={onBack} data-testid="button-back">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold">{mockEvent.title}</h1>
            <StatusBadge status={mockEvent.status} />
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1 flex-wrap">
            <span className="flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              {mockEvent.city}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {format(mockEvent.date, "d MMM yyyy", { locale: ru })}
            </span>
            <span>{mockEvent.discipline}</span>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="calendar" data-testid="tab-calendar">Календарь</TabsTrigger>
          <TabsTrigger value="budget" data-testid="tab-budget">Бюджет</TabsTrigger>
          <TabsTrigger value="checklist" data-testid="tab-checklist">
            Чеклист
            <span className="ml-1.5 text-xs text-muted-foreground">
              {completedTasks}/{mockChecklist.length}
            </span>
          </TabsTrigger>
          <TabsTrigger value="report" data-testid="tab-report">Отчёт</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>Информация о событии</CardTitle>
              {userRole === "city_org" && mockEvent.status === "calendar_draft" && (
                <div className="flex gap-2 flex-wrap">
                  <Button variant="outline" size="sm" data-testid="button-save-draft">
                    <Save className="h-4 w-4 mr-1" />
                    Сохранить
                  </Button>
                  <Button size="sm" data-testid="button-submit-calendar">
                    <Send className="h-4 w-4 mr-1" />
                    На утверждение
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-muted-foreground">Название</Label>
                    <p className="font-medium">{mockEvent.title}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Дисциплина</Label>
                    <p className="font-medium">{mockEvent.discipline}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Формат</Label>
                    <p className="font-medium">{mockEvent.format}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label className="text-muted-foreground">Дата проведения</Label>
                    <p className="font-medium">
                      {format(mockEvent.date, "d MMMM yyyy", { locale: ru })} — {format(mockEvent.endDate, "d MMMM yyyy", { locale: ru })}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Дедлайн анонса</Label>
                    <p className="font-medium">{format(mockEvent.announceDeadline, "d MMMM yyyy", { locale: ru })}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Призовой фонд</Label>
                    <p className="font-medium font-mono">{formatCurrency(mockEvent.prizePool)}</p>
                  </div>
                </div>
              </div>
              <div>
                <Label className="text-muted-foreground">Описание</Label>
                <p className="mt-1">{mockEvent.description}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="budget" className="mt-6 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>Бюджет события</CardTitle>
              {mockBudget.approved && (
                <Badge variant="default">Утверждён</Badge>
              )}
            </CardHeader>
            <CardContent className="space-y-6">
              {mockBudget.items.map((category) => (
                <div key={category.category} className="space-y-2">
                  <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
                    {category.category}
                  </h4>
                  <div className="space-y-1">
                    {category.items.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between py-1.5 border-b border-border/50 last:border-0">
                        <span className="text-sm">{item.name}</span>
                        <span className="font-mono text-sm">{formatCurrency(item.amount)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              <div className="pt-4 border-t flex items-center justify-between">
                <span className="text-lg font-semibold">Итого</span>
                <span className="text-2xl font-bold font-mono">{formatCurrency(mockBudget.total)}</span>
              </div>
              {mockBudget.approved && (
                <p className="text-sm text-muted-foreground">
                  Утверждено: {mockBudget.approvedBy}, {format(mockBudget.approvedAt, "d MMM yyyy", { locale: ru })}
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="checklist" className="mt-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between gap-4">
                <CardTitle>Чеклист подготовки</CardTitle>
                <span className="text-sm text-muted-foreground">{checklistProgress.toFixed(0)}% выполнено</span>
              </div>
              <Progress value={checklistProgress} className="h-2 mt-2" />
            </CardHeader>
            <CardContent className="space-y-2">
              {mockChecklist.map((item) => (
                <ChecklistItem
                  key={item.id}
                  {...item}
                  onToggle={(v) => console.log("Toggle", item.id, v)}
                />
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <CardTitle>Отчёт о событии</CardTitle>
              {userRole === "city_org" && (
                <Button size="sm" data-testid="button-save-report">
                  <Save className="h-4 w-4 mr-1" />
                  Сохранить отчёт
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="space-y-1">
                  <Label className="text-muted-foreground flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    Участников
                  </Label>
                  <p className="text-2xl font-bold font-mono">{mockReport.participants}</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">Регистраций</Label>
                  <p className="text-2xl font-bold font-mono">{mockReport.registrations}</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground flex items-center gap-1">
                    <Eye className="h-3 w-3" />
                    Зрителей трансляции
                  </Label>
                  <p className="text-2xl font-bold font-mono">{mockReport.streamViewers}</p>
                  <p className="text-xs text-muted-foreground">Пик: {mockReport.peakViewers}</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-muted-foreground">Просмотров постов</Label>
                  <p className="text-2xl font-bold font-mono">{mockReport.postViews.toLocaleString()}</p>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t space-y-4">
                <h4 className="font-semibold">Результаты</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-2 p-3 rounded-md bg-chart-4/10">
                    <Trophy className="h-5 w-5 text-chart-4" />
                    <div>
                      <p className="text-xs text-muted-foreground">1 место</p>
                      <p className="font-semibold">{mockReport.winner}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-md bg-muted">
                    <Trophy className="h-5 w-5 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">2 место</p>
                      <p className="font-semibold">{mockReport.secondPlace}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-md bg-chart-4/5">
                    <Trophy className="h-5 w-5 text-chart-4/60" />
                    <div>
                      <p className="text-xs text-muted-foreground">3 место</p>
                      <p className="font-semibold">{mockReport.thirdPlace}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t">
                <div className="flex items-center justify-between gap-4 mb-4">
                  <h4 className="font-semibold">Медиа</h4>
                  <Badge variant="secondary">{mockReport.mediaUploaded} файлов</Badge>
                </div>
                <div className="border-2 border-dashed border-border rounded-md p-8 text-center">
                  <p className="text-muted-foreground">Перетащите файлы сюда или</p>
                  <Button variant="outline" className="mt-2" data-testid="button-upload-media">
                    Выберите файлы
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
