import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import BudgetProgress from "../BudgetProgress";
import EventCard from "../EventCard";
import StatusBadge from "../StatusBadge";
import { Plus, Calendar, AlertTriangle } from "lucide-react";
import type { Event, City } from "@shared/schema";

interface CityOrgDashboardProps {
  onNavigateEvent?: (eventId: string) => void;
  onCreateEvent?: () => void;
  cityId?: string;
}

export default function CityOrgDashboard({ onNavigateEvent, onCreateEvent, cityId }: CityOrgDashboardProps) {
  const [activeTab, setActiveTab] = useState("upcoming");
  const currentYear = new Date().getFullYear();

  const { data: city, isLoading: cityLoading } = useQuery<City>({
    queryKey: [`/api/cities/${cityId}`],
    enabled: !!cityId,
  });

  const { data: events = [], isLoading: eventsLoading } = useQuery<Event[]>({
    queryKey: [`/api/events?cityId=${cityId}`],
    enabled: !!cityId,
  });

  const isLoading = cityLoading || eventsLoading;

  const upcomingEvents = events.filter((e) => {
    const eventDate = new Date(e.date);
    return eventDate >= new Date() && e.status !== "completed";
  });

  const pastEvents = events.filter((e) => {
    const eventDate = new Date(e.date);
    return eventDate < new Date() || e.status === "completed";
  });

  const deadlineWarnings = upcomingEvents
    .map((event) => {
      const eventDate = new Date(event.date);
      const now = new Date();
      const daysLeft = Math.ceil((eventDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysLeft <= 7) {
        return {
          eventId: event.id,
          eventTitle: event.title,
          type: event.status.includes("pending") ? "approve" : "prepare",
          daysLeft,
        };
      }
      return null;
    })
    .filter(Boolean) as { eventId: string; eventTitle: string; type: string; daysLeft: number }[];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <Skeleton className="h-9 w-40 mb-2" />
            <Skeleton className="h-5 w-60" />
          </div>
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="h-40 lg:col-span-2" />
          <Skeleton className="h-40" />
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      </div>
    );
  }

  const cityBudget = {
    total: Number(city?.totalBudget || 0),
    approved: Number(city?.approvedBudget || 0),
    spent: Number(city?.spentBudget || 0),
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-city-name">{city?.name || "Город"}</h1>
          <p className="text-muted-foreground">Управление событиями города</p>
        </div>
        <Button onClick={onCreateEvent} data-testid="button-create-event">
          <Plus className="h-4 w-4 mr-2" />
          Создать событие
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Бюджет {currentYear}</CardTitle>
          </CardHeader>
          <CardContent>
            <BudgetProgress
              total={cityBudget.total}
              approved={cityBudget.approved}
              spent={cityBudget.spent}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-chart-4" />
              Дедлайны
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {deadlineWarnings.length === 0 ? (
              <p className="text-sm text-muted-foreground">Нет активных дедлайнов</p>
            ) : (
              deadlineWarnings.map((warning) => (
                <div
                  key={`${warning.eventId}-${warning.type}`}
                  className="flex items-start justify-between gap-2 p-2 rounded-md bg-muted/50"
                >
                  <div className="min-w-0">
                    <p
                      className="text-sm font-medium truncate cursor-pointer"
                      onClick={() => onNavigateEvent?.(warning.eventId)}
                    >
                      {warning.eventTitle}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {warning.type === "approve" ? "Ожидает утверждения" : "Подготовка"}
                    </p>
                  </div>
                  <StatusBadge
                    status={warning.daysLeft < 0 ? "overdue" : warning.daysLeft <= 3 ? "due_soon" : "upcoming"}
                  />
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="upcoming" data-testid="tab-upcoming">
            Предстоящие ({upcomingEvents.length})
          </TabsTrigger>
          <TabsTrigger value="past" data-testid="tab-past">
            Прошедшие ({pastEvents.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-4 mt-6">
          {upcomingEvents.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground mb-4">Нет предстоящих событий</p>
                <Button onClick={onCreateEvent}>
                  <Plus className="h-4 w-4 mr-2" />
                  Создать первое событие
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {upcomingEvents.map((event) => (
                <EventCard
                  key={event.id}
                  id={event.id}
                  title={event.title}
                  city={city?.name || ""}
                  date={new Date(event.date)}
                  discipline={event.discipline}
                  status={event.status}
                  participantsCount={event.participantsCount || undefined}
                  winner={event.winner || undefined}
                  onClick={() => onNavigateEvent?.(event.id)}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="past" className="space-y-4 mt-6">
          {pastEvents.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Нет прошедших событий</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {pastEvents.map((event) => (
                <EventCard
                  key={event.id}
                  id={event.id}
                  title={event.title}
                  city={city?.name || ""}
                  date={new Date(event.date)}
                  discipline={event.discipline}
                  status={event.status}
                  participantsCount={event.participantsCount || undefined}
                  winner={event.winner || undefined}
                  onClick={() => onNavigateEvent?.(event.id)}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
