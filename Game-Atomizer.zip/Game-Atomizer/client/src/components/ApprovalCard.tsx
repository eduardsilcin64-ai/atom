import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, FileText, Wallet, Loader2 } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { ru } from "date-fns/locale";

type ApprovalType = "calendar" | "budget";

interface ApprovalCardProps {
  id: string;
  eventTitle: string;
  city: string;
  type: ApprovalType;
  eventDate: Date;
  submittedAt: Date;
  budgetAmount?: number;
  onApprove: () => void;
  onReject: () => void;
  onView: () => void;
  isApproving?: boolean;
  isRejecting?: boolean;
}

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0,
  }).format(amount);
}

export default function ApprovalCard({
  id,
  eventTitle,
  city,
  type,
  eventDate,
  submittedAt,
  budgetAmount,
  onApprove,
  onReject,
  onView,
  isApproving,
  isRejecting,
}: ApprovalCardProps) {
  const isCalendar = type === "calendar";
  const Icon = isCalendar ? FileText : Wallet;

  return (
    <Card data-testid={`approval-card-${id}`}>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-md bg-primary/10 text-primary">
              <Icon className="h-4 w-4" />
            </div>
            <div>
              <p className="font-medium">{eventTitle}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {city}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {format(eventDate, "d MMM yyyy", { locale: ru })}
                </span>
              </div>
            </div>
          </div>
          <Badge variant={isCalendar ? "secondary" : "outline"}>
            {isCalendar ? "Календарь" : "Бюджет"}
          </Badge>
        </div>

        {type === "budget" && budgetAmount !== undefined && (
          <p className="text-sm">
            Сумма: <span className="font-mono font-semibold">{formatCurrency(budgetAmount)}</span>
          </p>
        )}

        <p className="text-xs text-muted-foreground">
          Отправлено {formatDistanceToNow(submittedAt, { addSuffix: true, locale: ru })}
        </p>

        <div className="flex items-center gap-2 flex-wrap">
          <Button size="sm" onClick={onApprove} disabled={isApproving || isRejecting} data-testid={`button-approve-${id}`}>
            {isApproving && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
            Утвердить
          </Button>
          <Button size="sm" variant="outline" onClick={onReject} disabled={isApproving || isRejecting} data-testid={`button-reject-${id}`}>
            {isRejecting && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
            Отклонить
          </Button>
          <Button size="sm" variant="ghost" onClick={onView} data-testid={`button-view-${id}`}>
            Подробнее
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
