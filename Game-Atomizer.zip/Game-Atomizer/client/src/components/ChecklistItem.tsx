import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { format, isBefore } from "date-fns";
import { ru } from "date-fns/locale";
import { useState } from "react";

interface ChecklistItemProps {
  id: string;
  title: string;
  assignee: "city_org" | "smm";
  dueDate: Date;
  completed: boolean;
  onToggle: (completed: boolean) => void;
}

export default function ChecklistItem({
  id,
  title,
  assignee,
  dueDate,
  completed,
  onToggle,
}: ChecklistItemProps) {
  const [isChecked, setIsChecked] = useState(completed);
  const isOverdue = !completed && isBefore(dueDate, new Date());
  const assigneeLabel = assignee === "city_org" ? "Организатор" : "SMM";

  const handleToggle = () => {
    const newValue = !isChecked;
    setIsChecked(newValue);
    onToggle(newValue);
  };

  return (
    <div 
      className={cn(
        "flex items-start gap-3 p-3 rounded-md border transition-colors",
        isChecked && "bg-muted/50",
        isOverdue && "border-destructive/50 bg-destructive/5"
      )}
      data-testid={`checklist-item-${id}`}
    >
      <Checkbox 
        checked={isChecked} 
        onCheckedChange={handleToggle}
        className="mt-0.5"
        data-testid={`checkbox-${id}`}
      />
      <div className="flex-1 min-w-0 space-y-1">
        <p className={cn(
          "text-sm font-medium",
          isChecked && "line-through text-muted-foreground"
        )}>
          {title}
        </p>
        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="secondary" className="text-xs">
            {assigneeLabel}
          </Badge>
          <span className={cn(
            "text-xs",
            isOverdue ? "text-destructive font-medium" : "text-muted-foreground"
          )}>
            До {format(dueDate, "d MMM", { locale: ru })}
          </span>
        </div>
      </div>
    </div>
  );
}
