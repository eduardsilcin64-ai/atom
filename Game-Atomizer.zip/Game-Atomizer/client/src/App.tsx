import { useState } from "react";
import { Switch, Route, useLocation, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Bell, Loader2 } from "lucide-react";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/LoginPage";
import CitiesPage from "@/pages/CitiesPage";
import EventsPage from "@/pages/EventsPage";
import SocialAnalyticsPage from "@/pages/SocialAnalyticsPage";
import UsersPage from "@/pages/UsersPage";
import BudgetPage from "@/pages/BudgetPage";
import NotificationsPage from "@/pages/NotificationsPage";
import SettingsPage from "@/pages/SettingsPage";
import MediaPage from "@/pages/MediaPage";
import AppSidebar from "@/components/AppSidebar";
import ThemeToggle from "@/components/ThemeToggle";
import SuperAdminDashboard from "@/components/dashboard/SuperAdminDashboard";
import CityOrgDashboard from "@/components/dashboard/CityOrgDashboard";
import SMMDashboard from "@/components/dashboard/SMMDashboard";
import EventDetailPage from "@/components/dashboard/EventDetailPage";
import EventCreateDialog from "@/components/EventCreateDialog";
import { AuthProvider, useAuth } from "@/hooks/use-auth";

type UserRole = "super_admin" | "city_org" | "smm";

function MainLayout({ children, role, userName, cityName, pendingCount }: {
  children: React.ReactNode;
  role: UserRole;
  userName: string;
  cityName?: string;
  pendingCount?: number;
}) {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar 
          role={role} 
          userName={userName} 
          cityName={cityName}
          pendingCount={pendingCount}
        />
        <div className="flex flex-col flex-1 min-w-0">
          <header className="flex items-center justify-between gap-4 p-3 border-b bg-background sticky top-0 z-50">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" data-testid="button-notifications">
                <Bell className="h-5 w-5" />
              </Button>
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function SuperAdminRoutes({ userName, userEmail }: { userName: string; userEmail: string }) {
  const [, setLocation] = useLocation();
  
  return (
    <Switch>
      <Route path="/">
        <SuperAdminDashboard 
          onNavigateCity={(id) => setLocation(`/cities/${id}`)}
          onNavigateEvent={(id) => setLocation(`/events/${id}`)}
        />
      </Route>
      <Route path="/cities">
        <CitiesPage onNavigateCity={(id) => setLocation(`/cities/${id}`)} />
      </Route>
      <Route path="/cities/:id">
        {() => (
          <CityOrgDashboard 
            onNavigateEvent={(id) => setLocation(`/events/${id}`)}
            onCreateEvent={() => setLocation("/events/new")}
          />
        )}
      </Route>
      <Route path="/events">
        <EventsPage 
          onNavigateEvent={(id) => setLocation(`/events/${id}`)}
          userRole="super_admin"
        />
      </Route>
      <Route path="/events/:id">
        {(params) => (
          <EventDetailPage 
            eventId={params.id}
            userRole="super_admin"
            onBack={() => setLocation("/")}
          />
        )}
      </Route>
      <Route path="/approvals">
        <SuperAdminDashboard 
          onNavigateCity={(id) => setLocation(`/cities/${id}`)}
          onNavigateEvent={(id) => setLocation(`/events/${id}`)}
        />
      </Route>
      <Route path="/analytics">
        <SocialAnalyticsPage userRole="super_admin" />
      </Route>
      <Route path="/users">
        <UsersPage />
      </Route>
      <Route path="/settings">
        <SettingsPage userName={userName} userEmail={userEmail} userRole="super_admin" />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function CityOrgRoutes({ userName, userEmail, cityName }: { userName: string; userEmail: string; cityName: string }) {
  const [, setLocation] = useLocation();
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  
  return (
    <>
      <Switch>
        <Route path="/">
          <CityOrgDashboard 
            onNavigateEvent={(id) => setLocation(`/events/${id}`)}
            onCreateEvent={() => setCreateDialogOpen(true)}
          />
        </Route>
        <Route path="/events">
          <EventsPage 
            onNavigateEvent={(id) => setLocation(`/events/${id}`)}
            userRole="city_org"
          />
        </Route>
        <Route path="/events/:id">
          {(params) => (
            <EventDetailPage 
              eventId={params.id}
              userRole="city_org"
              onBack={() => setLocation("/")}
            />
          )}
        </Route>
        <Route path="/budget">
          <BudgetPage />
        </Route>
        <Route path="/notifications">
          <NotificationsPage />
        </Route>
        <Route path="/settings">
          <SettingsPage userName={userName} userEmail={userEmail} userRole="city_org" />
        </Route>
        <Route component={NotFound} />
      </Switch>
      <EventCreateDialog 
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        cityName={cityName}
        onSubmit={(data) => console.log("Create event:", data)}
      />
    </>
  );
}

function SMMRoutes({ userName, userEmail }: { userName: string; userEmail: string }) {
  const [, setLocation] = useLocation();
  
  return (
    <Switch>
      <Route path="/">
        <SMMDashboard 
          onNavigateEvent={(id) => setLocation(`/events/${id}`)}
        />
      </Route>
      <Route path="/tasks">
        <SMMDashboard 
          onNavigateEvent={(id) => setLocation(`/events/${id}`)}
        />
      </Route>
      <Route path="/media">
        <MediaPage />
      </Route>
      <Route path="/analytics">
        <SocialAnalyticsPage userRole="smm" />
      </Route>
      <Route path="/events/:id">
        {(params) => (
          <EventDetailPage 
            eventId={params.id}
            userRole="smm"
            onBack={() => setLocation("/")}
          />
        )}
      </Route>
      <Route path="/settings">
        <SettingsPage userName={userName} userEmail={userEmail} userRole="smm" />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function ProtectedApp() {
  const { user, isLoading, isAuthenticated, logout } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    if (location !== "/login") {
      return <Redirect to="/login" />;
    }
    return <LoginPage />;
  }

  if (location === "/login") {
    return <Redirect to="/" />;
  }

  const userRole = user.role as UserRole;
  const userName = user.name;
  const userEmail = user.email;
  const cityName = user.cityName || "";
  const pendingCount = userRole === "super_admin" ? 3 : 0;

  return (
    <MainLayout 
      role={userRole}
      userName={userName}
      cityName={cityName}
      pendingCount={pendingCount}
    >
      {userRole === "super_admin" && <SuperAdminRoutes userName={userName} userEmail={userEmail} />}
      {userRole === "city_org" && <CityOrgRoutes userName={userName} userEmail={userEmail} cityName={cityName} />}
      {userRole === "smm" && <SMMRoutes userName={userName} userEmail={userEmail} />}
    </MainLayout>
  );
}

function AppRouter() {
  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      <Route>
        <ProtectedApp />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <AppRouter />
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
