import { db } from "./db";
import { users, cities, events, socialStats, smmReports } from "@shared/schema";
import bcrypt from "bcrypt";

const SALT_ROUNDS = 10;

async function seed() {
  console.log("Seeding database...");

  const existingCities = await db.select().from(cities);
  if (existingCities.length > 0) {
    console.log("Database already seeded, skipping...");
    return;
  }

  const [balakovo, obninsk, kurchatov, sosnovyBor, novovoronezh] = await db.insert(cities).values([
    { name: "Балаково", organizerName: "Иванов Иван Иванович", totalBudget: "500000", spentBudget: "150000", approvedBudget: "200000" },
    { name: "Обнинск", organizerName: "Петров Пётр Петрович", totalBudget: "450000", spentBudget: "120000", approvedBudget: "180000" },
    { name: "Курчатов", organizerName: "Сидоров Сергей Сергеевич", totalBudget: "400000", spentBudget: "80000", approvedBudget: "150000" },
    { name: "Сосновый Бор", organizerName: "Козлова Анна Викторовна", totalBudget: "480000", spentBudget: "200000", approvedBudget: "250000" },
    { name: "Нововоронеж", organizerName: "Морозов Дмитрий Константинович", totalBudget: "420000", spentBudget: "100000", approvedBudget: "170000" },
  ]).returning();

  console.log("Cities created:", [balakovo, obninsk, kurchatov, sosnovyBor, novovoronezh].map(c => c.name));

  const hashedPassword = await bcrypt.hash("password123", SALT_ROUNDS);
  const hashedAdminPassword = await bcrypt.hash("admin123", SALT_ROUNDS);

  const createdUsers = await db.insert(users).values([
    { name: "Администратор", email: "admin@atom.game", password: hashedAdminPassword, role: "super_admin", isActive: true },
    { name: "Иванов Иван Иванович", email: "ivanov@atom.game", password: hashedPassword, role: "city_org", cityId: balakovo.id, isActive: true },
    { name: "Петров Пётр Петрович", email: "petrov@atom.game", password: hashedPassword, role: "city_org", cityId: obninsk.id, isActive: true },
    { name: "Сидоров Сергей Сергеевич", email: "sidorov@atom.game", password: hashedPassword, role: "city_org", cityId: kurchatov.id, isActive: true },
    { name: "Козлова Анна Викторовна", email: "kozlova@atom.game", password: hashedPassword, role: "city_org", cityId: sosnovyBor.id, isActive: true },
    { name: "Морозов Дмитрий Константинович", email: "morozov@atom.game", password: hashedPassword, role: "city_org", cityId: novovoronezh.id, isActive: false },
    { name: "SMM Менеджер 1", email: "smm1@atom.game", password: hashedPassword, role: "smm", isActive: true },
    { name: "SMM Менеджер 2", email: "smm2@atom.game", password: hashedPassword, role: "smm", isActive: true },
  ]).returning();

  const smmUser = createdUsers.find(u => u.email === "smm1@atom.game");
  console.log("Users created with hashed passwords");

  const now = new Date();
  const createdEvents = await db.insert(events).values([
    { 
      title: "Кубок CS2 Балаково", 
      cityId: balakovo.id, 
      date: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000), 
      discipline: "Counter-Strike 2", 
      format: "offline", 
      status: "calendar_approved", 
      participantsCount: 32,
      registrationUrl: "https://forms.google.com/cs2-balakovo",
      regulationsUrl: "https://docs.google.com/cs2-rules",
      budget: "50000"
    },
    { 
      title: "Турнир FIFA Балаково", 
      cityId: balakovo.id, 
      date: new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000), 
      discipline: "FIFA 24", 
      format: "online", 
      status: "calendar_pending", 
      participantsCount: 64,
      registrationUrl: "https://forms.google.com/fifa-balakovo",
      budget: "30000"
    },
    { 
      title: "Чемпионат Dota 2", 
      cityId: obninsk.id, 
      date: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000), 
      discipline: "Dota 2", 
      format: "offline", 
      status: "budget_pending", 
      participantsCount: 16,
      budget: "75000"
    },
    { 
      title: "Лига Valorant", 
      cityId: obninsk.id, 
      date: new Date(now.getTime() + 21 * 24 * 60 * 60 * 1000), 
      discipline: "Valorant", 
      format: "online", 
      status: "calendar_draft", 
      participantsCount: 24,
      budget: "25000"
    },
    { 
      title: "Турнир Mobile Legends", 
      cityId: kurchatov.id, 
      date: new Date(now.getTime() + 10 * 24 * 60 * 60 * 1000), 
      discipline: "Mobile Legends", 
      format: "online", 
      status: "calendar_approved", 
      participantsCount: 48,
      registrationUrl: "https://forms.google.com/ml-kurchatov",
      budget: "40000"
    },
    { 
      title: "Кубок по League of Legends", 
      cityId: sosnovyBor.id, 
      date: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000), 
      discipline: "League of Legends", 
      format: "offline", 
      status: "completed", 
      participantsCount: 20, 
      winner: "Team Alpha",
      mediaLinks: ["https://vk.com/album/lol-cup", "https://youtube.com/watch?v=lol-highlights"],
      budget: "60000"
    },
    { 
      title: "Финал PUBG Mobile", 
      cityId: novovoronezh.id, 
      date: new Date(now.getTime() + 28 * 24 * 60 * 60 * 1000), 
      discipline: "PUBG Mobile", 
      format: "online", 
      status: "budget_draft", 
      participantsCount: 100,
      budget: "80000"
    },
    { 
      title: "Турнир Fortnite", 
      cityId: balakovo.id, 
      date: new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000), 
      discipline: "Fortnite", 
      format: "online", 
      status: "completed", 
      participantsCount: 50, 
      winner: "ProGamer2024",
      mediaLinks: ["https://vk.com/album/fortnite-cup"],
      streamUrl: "https://youtube.com/watch?v=fortnite-stream",
      budget: "35000"
    },
  ]).returning();

  console.log("Events created");

  if (smmUser) {
    const completedEvent = createdEvents.find(e => e.status === "completed");
    if (completedEvent) {
      await db.insert(smmReports).values([
        {
          eventId: completedEvent.id,
          smmUserId: smmUser.id,
          title: "Отчёт по турниру League of Legends",
          content: "Турнир прошёл успешно. Охват в соцсетях составил 15,000 просмотров. Опубликовано 12 постов.",
          status: "submitted",
          views: 15000,
          likes: 850,
          reposts: 120,
          reach: 25000,
          mediaLinks: ["https://vk.com/post1", "https://vk.com/post2"],
          submittedAt: new Date()
        }
      ]);
      console.log("SMM reports created");
    }
  }

  const months = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"];
  const platforms = ["vk", "telegram", "youtube"];
  
  for (const month of months) {
    for (const platform of platforms) {
      const baseViews = platform === "vk" ? 15000 : platform === "telegram" ? 8000 : 25000;
      const variance = Math.floor(Math.random() * 5000) - 2500;
      
      await db.insert(socialStats).values({
        platform,
        month,
        year: 2024,
        views: baseViews + variance,
        subscribers: Math.floor((baseViews + variance) * 0.1),
        engagement: String(Math.random() * 5 + 2),
      });
    }
  }

  console.log("Social stats created");
  console.log("Seeding completed!");
}

seed()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("Seed error:", error);
    process.exit(1);
  });
