import { 
  users, cities, events, expenses, socialStats, notifications, smmReports,
  type User, type InsertUser,
  type City, type InsertCity,
  type Event, type InsertEvent,
  type Expense, type InsertExpense,
  type SocialStats, type InsertSocialStats,
  type Notification, type InsertNotification,
  type SmmReport, type InsertSmmReport
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, gte, lte, and, or, sql } from "drizzle-orm";
import bcrypt from "bcrypt";

const SALT_ROUNDS = 10;

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  verifyPassword(email: string, password: string): Promise<User | null>;

  getCities(): Promise<City[]>;
  getCity(id: string): Promise<City | undefined>;
  createCity(city: InsertCity): Promise<City>;
  updateCity(id: string, city: Partial<InsertCity>): Promise<City | undefined>;
  deleteCity(id: string): Promise<boolean>;

  getEvents(): Promise<Event[]>;
  getEventsByCity(cityId: string): Promise<Event[]>;
  getEvent(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: string): Promise<boolean>;
  getUpcomingEvents(limit?: number): Promise<Event[]>;
  getCompletedEvents(limit?: number): Promise<Event[]>;
  getPendingApprovalEvents(): Promise<Event[]>;

  getSmmReports(eventId?: string): Promise<SmmReport[]>;
  getSmmReportsByUser(userId: string): Promise<SmmReport[]>;
  getSmmReport(id: string): Promise<SmmReport | undefined>;
  createSmmReport(report: InsertSmmReport): Promise<SmmReport>;
  updateSmmReport(id: string, report: Partial<InsertSmmReport>): Promise<SmmReport | undefined>;
  deleteSmmReport(id: string): Promise<boolean>;
  submitSmmReport(id: string): Promise<SmmReport | undefined>;

  getExpenses(cityId?: string): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: string, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: string): Promise<boolean>;
  approveExpense(id: string): Promise<Expense | undefined>;

  getSocialStats(cityId?: string): Promise<SocialStats[]>;
  createSocialStats(stats: InsertSocialStats): Promise<SocialStats>;
  deleteSocialStats(id: string): Promise<boolean>;

  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<void>;
  deleteNotification(id: string): Promise<boolean>;

  getDashboardStats(): Promise<{
    citiesCount: number;
    eventsCount: number;
    usersCount: number;
    pendingApprovals: number;
    totalBudget: number;
    spentBudget: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(users.name);
  }

  async createUser(user: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(user.password, SALT_ROUNDS);
    const [created] = await db.insert(users).values({
      ...user,
      password: hashedPassword
    }).returning();
    return created;
  }

  async updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined> {
    const updateData = { ...user };
    if (user.password) {
      updateData.password = await bcrypt.hash(user.password, SALT_ROUNDS);
    }
    const [updated] = await db.update(users).set(updateData).where(eq(users.id, id)).returning();
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id)).returning();
    return result.length > 0;
  }

  async verifyPassword(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email);
    if (!user) return null;
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getCities(): Promise<City[]> {
    return db.select().from(cities).orderBy(cities.name);
  }

  async getCity(id: string): Promise<City | undefined> {
    const [city] = await db.select().from(cities).where(eq(cities.id, id));
    return city;
  }

  async createCity(city: InsertCity): Promise<City> {
    const [created] = await db.insert(cities).values(city).returning();
    return created;
  }

  async updateCity(id: string, city: Partial<InsertCity>): Promise<City | undefined> {
    const [updated] = await db.update(cities).set(city).where(eq(cities.id, id)).returning();
    return updated;
  }

  async deleteCity(id: string): Promise<boolean> {
    const result = await db.delete(cities).where(eq(cities.id, id)).returning();
    return result.length > 0;
  }

  async getEvents(): Promise<Event[]> {
    return db.select().from(events).orderBy(desc(events.date));
  }

  async getEventsByCity(cityId: string): Promise<Event[]> {
    return db.select().from(events).where(eq(events.cityId, cityId)).orderBy(desc(events.date));
  }

  async getEvent(id: string): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event;
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const [created] = await db.insert(events).values(event).returning();
    return created;
  }

  async updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined> {
    const [updated] = await db.update(events).set(event).where(eq(events.id, id)).returning();
    return updated;
  }

  async deleteEvent(id: string): Promise<boolean> {
    const result = await db.delete(events).where(eq(events.id, id)).returning();
    return result.length > 0;
  }

  async getUpcomingEvents(limit: number = 10): Promise<Event[]> {
    return db.select().from(events)
      .where(gte(events.date, new Date()))
      .orderBy(events.date)
      .limit(limit);
  }

  async getCompletedEvents(limit: number = 10): Promise<Event[]> {
    return db.select().from(events)
      .where(eq(events.status, "completed"))
      .orderBy(desc(events.date))
      .limit(limit);
  }

  async getPendingApprovalEvents(): Promise<Event[]> {
    return db.select().from(events)
      .where(or(
        eq(events.status, "calendar_pending"),
        eq(events.status, "budget_pending")
      ))
      .orderBy(events.date);
  }

  async getSmmReports(eventId?: string): Promise<SmmReport[]> {
    if (eventId) {
      return db.select().from(smmReports).where(eq(smmReports.eventId, eventId)).orderBy(desc(smmReports.createdAt));
    }
    return db.select().from(smmReports).orderBy(desc(smmReports.createdAt));
  }

  async getSmmReportsByUser(userId: string): Promise<SmmReport[]> {
    return db.select().from(smmReports).where(eq(smmReports.smmUserId, userId)).orderBy(desc(smmReports.createdAt));
  }

  async getSmmReport(id: string): Promise<SmmReport | undefined> {
    const [report] = await db.select().from(smmReports).where(eq(smmReports.id, id));
    return report;
  }

  async createSmmReport(report: InsertSmmReport): Promise<SmmReport> {
    const [created] = await db.insert(smmReports).values(report).returning();
    return created;
  }

  async updateSmmReport(id: string, report: Partial<InsertSmmReport>): Promise<SmmReport | undefined> {
    const [updated] = await db.update(smmReports).set(report).where(eq(smmReports.id, id)).returning();
    return updated;
  }

  async deleteSmmReport(id: string): Promise<boolean> {
    const result = await db.delete(smmReports).where(eq(smmReports.id, id)).returning();
    return result.length > 0;
  }

  async submitSmmReport(id: string): Promise<SmmReport | undefined> {
    const [updated] = await db.update(smmReports)
      .set({ status: "submitted", submittedAt: new Date() })
      .where(eq(smmReports.id, id))
      .returning();
    return updated;
  }

  async getExpenses(cityId?: string): Promise<Expense[]> {
    if (cityId) {
      return db.select().from(expenses).where(eq(expenses.cityId, cityId)).orderBy(desc(expenses.date));
    }
    return db.select().from(expenses).orderBy(desc(expenses.date));
  }

  async createExpense(expense: InsertExpense): Promise<Expense> {
    const [created] = await db.insert(expenses).values(expense).returning();
    return created;
  }

  async updateExpense(id: string, expense: Partial<InsertExpense>): Promise<Expense | undefined> {
    const [updated] = await db.update(expenses).set(expense).where(eq(expenses.id, id)).returning();
    return updated;
  }

  async deleteExpense(id: string): Promise<boolean> {
    const result = await db.delete(expenses).where(eq(expenses.id, id)).returning();
    return result.length > 0;
  }

  async approveExpense(id: string): Promise<Expense | undefined> {
    const [updated] = await db.update(expenses)
      .set({ isApproved: true })
      .where(eq(expenses.id, id))
      .returning();
    return updated;
  }

  async getSocialStats(cityId?: string): Promise<SocialStats[]> {
    if (cityId) {
      return db.select().from(socialStats).where(eq(socialStats.cityId, cityId));
    }
    return db.select().from(socialStats);
  }

  async createSocialStats(stats: InsertSocialStats): Promise<SocialStats> {
    const [created] = await db.insert(socialStats).values(stats).returning();
    return created;
  }

  async deleteSocialStats(id: string): Promise<boolean> {
    const result = await db.delete(socialStats).where(eq(socialStats.id, id)).returning();
    return result.length > 0;
  }

  async getNotifications(userId: string): Promise<Notification[]> {
    return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(notification).returning();
    return created;
  }

  async markNotificationRead(id: string): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }

  async deleteNotification(id: string): Promise<boolean> {
    const result = await db.delete(notifications).where(eq(notifications.id, id)).returning();
    return result.length > 0;
  }

  async getDashboardStats(): Promise<{
    citiesCount: number;
    eventsCount: number;
    usersCount: number;
    pendingApprovals: number;
    totalBudget: number;
    spentBudget: number;
  }> {
    const [citiesList, eventsList, usersList] = await Promise.all([
      this.getCities(),
      this.getEvents(),
      this.getUsers()
    ]);

    const pendingApprovals = eventsList.filter(e => 
      e.status === "calendar_pending" || e.status === "budget_pending"
    ).length;

    const totalBudget = citiesList.reduce((sum, city) => sum + Number(city.totalBudget || 0), 0);
    const spentBudget = citiesList.reduce((sum, city) => sum + Number(city.spentBudget || 0), 0);

    return {
      citiesCount: citiesList.length,
      eventsCount: eventsList.length,
      usersCount: usersList.length,
      pendingApprovals,
      totalBudget,
      spentBudget
    };
  }
}

export const storage = new DatabaseStorage();
