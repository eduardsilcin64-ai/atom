import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoleEnum = pgEnum("user_role", ["super_admin", "city_org", "smm"]);

export const eventStatusEnum = pgEnum("event_status", [
  "calendar_draft",
  "calendar_pending", 
  "calendar_approved",
  "budget_draft",
  "budget_pending",
  "budget_approved",
  "completed"
]);

export const reportStatusEnum = pgEnum("report_status", ["draft", "submitted", "approved", "rejected"]);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").notNull().default("city_org"),
  cityId: varchar("city_id"),
  isActive: boolean("is_active").notNull().default(true),
  lastActive: timestamp("last_active").default(sql`now()`),
});

export const cities = pgTable("cities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  organizerName: text("organizer_name").notNull(),
  totalBudget: decimal("total_budget", { precision: 12, scale: 2 }).notNull().default("0"),
  spentBudget: decimal("spent_budget", { precision: 12, scale: 2 }).notNull().default("0"),
  approvedBudget: decimal("approved_budget", { precision: 12, scale: 2 }).notNull().default("0"),
  isActive: boolean("is_active").notNull().default(true),
});

export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  cityId: varchar("city_id").notNull(),
  date: timestamp("date").notNull(),
  discipline: text("discipline").notNull(),
  format: text("format").notNull().default("offline"),
  description: text("description"),
  status: eventStatusEnum("status").notNull().default("calendar_draft"),
  participantsCount: integer("participants_count").default(0),
  winner: text("winner"),
  budget: decimal("budget", { precision: 12, scale: 2 }).default("0"),
  registrationUrl: text("registration_url"),
  regulationsUrl: text("regulations_url"),
  streamUrl: text("stream_url"),
  mediaLinks: text("media_links").array(),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const smmReports = pgTable("smm_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull(),
  smmUserId: varchar("smm_user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  status: reportStatusEnum("status").notNull().default("draft"),
  views: integer("views").default(0),
  likes: integer("likes").default(0),
  reposts: integer("reposts").default(0),
  reach: integer("reach").default(0),
  mediaLinks: text("media_links").array(),
  submittedAt: timestamp("submitted_at"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cityId: varchar("city_id").notNull(),
  eventId: varchar("event_id"),
  category: text("category").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  date: timestamp("date").default(sql`now()`),
  isApproved: boolean("is_approved").notNull().default(false),
});

export const socialStats = pgTable("social_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  cityId: varchar("city_id"),
  platform: text("platform").notNull(),
  month: text("month").notNull(),
  year: integer("year").notNull(),
  views: integer("views").notNull().default(0),
  subscribers: integer("subscribers").default(0),
  engagement: decimal("engagement", { precision: 5, scale: 2 }).default("0"),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, lastActive: true });
export const insertCitySchema = createInsertSchema(cities).omit({ id: true });
export const insertEventSchema = createInsertSchema(events).omit({ id: true, createdAt: true });
export const insertSmmReportSchema = createInsertSchema(smmReports).omit({ id: true, createdAt: true, submittedAt: true });
export const insertExpenseSchema = createInsertSchema(expenses).omit({ id: true, date: true });
export const insertSocialStatsSchema = createInsertSchema(socialStats).omit({ id: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCity = z.infer<typeof insertCitySchema>;
export type City = typeof cities.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertSmmReport = z.infer<typeof insertSmmReportSchema>;
export type SmmReport = typeof smmReports.$inferSelect;

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

export type InsertSocialStats = z.infer<typeof insertSocialStatsSchema>;
export type SocialStats = typeof socialStats.$inferSelect;

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

export type UserRole = "super_admin" | "city_org" | "smm";
export type EventStatus = "calendar_draft" | "calendar_pending" | "calendar_approved" | "budget_draft" | "budget_pending" | "budget_approved" | "completed";
export type ReportStatus = "draft" | "submitted" | "approved" | "rejected";
